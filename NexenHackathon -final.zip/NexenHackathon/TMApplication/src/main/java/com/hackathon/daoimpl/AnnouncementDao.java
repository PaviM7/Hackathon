package com.hackathon.daoimpl;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.expression.ParseException;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;

import com.hackathon.bean.AnnouncementBean;
import com.hackathon.dao.IAnnouncementDAO;
import com.hackathon.rowmapper.AnnouncementRowMapper;

@Component
public class AnnouncementDao extends JdbcDaoSupport implements IAnnouncementDAO {

	
	@Autowired
	public AnnouncementDao(DataSource dataSource) {
		// TODO Auto-generated constructor stub
		setDataSource(dataSource);
	}

	@Autowired
private Properties queryProps;
	
	public Properties getQueryProps() {
		return queryProps;
	}

	public void setQueryProps(Properties queryProps) {
		this.queryProps = queryProps;
	}

	public List<AnnouncementBean> getAllMeetings() throws ParseException  {
		// TODO Auto-generated method stub
		List<AnnouncementBean> AnnouncementList = new ArrayList<AnnouncementBean>();
int temp = 0;
		try{
		String sql = queryProps.getProperty("getMeetings");
		System.out.println(sql);
		AnnouncementList = getJdbcTemplate().query(sql,new Object[] {},new AnnouncementRowMapper());
		Iterator<AnnouncementBean> itr = AnnouncementList.iterator();
		//for(AnnouncementBean ab:itr.next())
		while(itr.hasNext())
		{
			AnnouncementBean ab = itr.next();
			String date = ab.getMeetingCommencement()+" "+ab.getMeetingTime();
			//Date date1=ab.getMeetingDate();  
			 //DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
             
             //to convert Date to String, use format method of SimpleDateFormat class.
             //String strDate = dateFormat.format(date1);
             //strDate  = strDate+" "+ab.getMeetingTime();
             Date date1 = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").parse(date);
			//System.out.println(strDate);

			
			Date date2 = new Date();
			
	        long diff = date2.getTime() - date1.getTime();
	        long diffSeconds = diff / 1000 % 60;
	        long diffMinutes = diff / (60 * 1000) % 60;
	        long diffHours = diff / (60 * 60 * 1000);
	        //System.out.println(diffHours);
	        int diffInDays = (int) ((date2.getTime() - date1.getTime()) / (1000 * 60 * 60 * 24));

	        if (diffHours > 2) 
	        {
	            System.out.println(ab.getStatus());
	    		int a = getJdbcTemplate().update("update T_XBBNHC9_MeetingDetails set status='over' where meetingNo="+ab.getMeetingNo(), new Object[]{});
System.out.println("over ");
	        } 
	        
	        else if (diffSeconds <0) 
	        {	            System.out.println(ab.getStatus()+" "+diffSeconds);
if(temp==0){
	    		int a = getJdbcTemplate().update("update T_XBBNHC9_MeetingDetails set status='forth coming' where meetingNo="+ab.getMeetingNo(), new Object[]{});
	    		System.out.println("yet to happen");
	    		temp=temp+1;
}
else
{
	int a = getJdbcTemplate().update("update T_XBBNHC9_MeetingDetails set status='yet to happen' where meetingNo="+ab.getMeetingNo(), new Object[]{});

}
	            
	        } else if ((diffHours<= 2) && (diffSeconds >0)) 
	        {	            System.out.println(ab.getStatus());

	    		int a = getJdbcTemplate().update("update T_XBBNHC9_MeetingDetails set status='in progress' where meetingNo="+ab.getMeetingNo(), new Object[]{});
	    		System.out.println("In Progress ");

	        }
	        
		}}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		return AnnouncementList;
	}

	public List<AnnouncementBean> getMeetingById(String st)  {
		// TODO Auto-generated method stub
		List<AnnouncementBean> AnnouncementList = new ArrayList<AnnouncementBean>();
		try{
		String sql = queryProps.getProperty("getOneMeeting");
		System.out.println(sql);
		AnnouncementBean AnnouncementBean  = new AnnouncementBean();		
		AnnouncementBean.setStatus(st);

		
		AnnouncementList = getJdbcTemplate().query(sql,new Object[] {AnnouncementBean.getStatus()},new AnnouncementRowMapper());
		System.out.println(AnnouncementList);
		if(AnnouncementList.size()==0)
		{
			System.out.println("in if ");
			 sql = queryProps.getProperty("getOneMeeting1");
			System.out.println(sql);
			//AnnouncementBean AnnouncementBean  = new AnnouncementBean();		
			AnnouncementBean.setStatus("over");
			

			
			AnnouncementList = getJdbcTemplate().query(sql,new Object[] {AnnouncementBean.getStatus()},new AnnouncementRowMapper());
			Iterator it= AnnouncementList.iterator();
			while(it.hasNext())
			{
				AnnouncementBean ab =(AnnouncementBean) it.next();
				System.out.println(ab.getMeetingNo());
			}
		}
		}
		catch(Exception e)
		{
			
		}
		return AnnouncementList;
	}

	public AnnouncementBean newMeeting(AnnouncementBean announcementBean) {
		// TODO Auto-generated method stub
		int numrows = 0;
		String SQL1 = queryProps.getProperty("setMeeting");
		
		
		try {
//System.out.println(announcementBean.getMeetingNo()+" "+new SimpleDateFormat("yyyy-MM-dd").parse(announcementBean.getMeetingDate())+" "+announcementBean.getMeetingTime()+" "+announcementBean.getMeetingVenue()+"     "+announcementBean.getMeetingDate());			
			numrows = getJdbcTemplate().update(SQL1,new Object[]{announcementBean.getMeetingNo(),new SimpleDateFormat("yyyy-MM-dd").parse(announcementBean.getMeetingCommencement()),announcementBean.getMeetingTime(),announcementBean.getMeetingVenue(),announcementBean.getStatus(),null});
		
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return( numrows == 1 ?  announcementBean: null);

		
	}
	public int removeMeeting(int id)
	{
		String SQL1 = queryProps.getProperty("deleteMeeting");
AnnouncementBean AnnouncementBean  = new AnnouncementBean();		
		AnnouncementBean.setMeetingNo(id);

		int a = getJdbcTemplate().update(SQL1, new Object[]{AnnouncementBean.getMeetingNo()});
		
		return a;
	}

	public int updateMeeting(int id,AnnouncementBean announcementBean)
	{
		String SQL1 = queryProps.getProperty("editMeeting");
announcementBean.setMeetingNo(id);
		int a=getJdbcTemplate().update(SQL1,new Object[]{announcementBean.getTheme(),announcementBean.getMeetingNo()});
		return a;
	}

	public List<AnnouncementBean> getMeetingById(int meetingNo) {
		String sql = queryProps.getProperty("getOneMeetingById");
		System.out.println(sql);
		AnnouncementBean AnnouncementBean  = new AnnouncementBean();		
		AnnouncementBean.setMeetingNo(meetingNo);

		List<AnnouncementBean> AnnouncementList = new ArrayList<AnnouncementBean>();
		AnnouncementList = getJdbcTemplate().query(sql,new Object[] {AnnouncementBean.getMeetingNo()},new AnnouncementRowMapper());
		return AnnouncementList;
	}

	public List<AnnouncementBean> getMeetingById() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
}
