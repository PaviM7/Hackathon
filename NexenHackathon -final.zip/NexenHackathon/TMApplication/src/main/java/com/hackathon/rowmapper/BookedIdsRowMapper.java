package com.hackathon.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.RowMapper;

public class BookedIdsRowMapper implements RowMapper<Integer> {

	public Integer mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		
		int bookedempids ;
		
		bookedempids = rs.getInt(1);
		
		return bookedempids;
	}

}
