package com.hackathon.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import com.hackathon.daoimpl.ApplicableRoles;

import com.hackathon.model.Data;
import com.hackathon.model.ErrorDetails;
import com.hackathon.model.MetaData;
import com.hackathon.model.Response;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class AvailableRolesController {
	
	
	@Autowired
	MetaData metaData;

	@Autowired
	Data data;
	@Autowired
	Response response;
	

	@ApiOperation(value = "retrieve past roles using GET method", notes = "Returns the roles details")
	@ApiParam(value = "objects that need to be invoked", required = true)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful Response", response = Response.class),
			@ApiResponse(code = 404, message = "Invalid Information Sent", response = Response.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = Response.class),
			@ApiResponse(code = 400, message = "Bad Request", response = Response.class) })

	@RequestMapping(value="pastroles/{id}",method = RequestMethod.GET)
	public List<String> viewPastroles(@ApiParam(value = "object that need to be deleted by using one id", required = true)@PathVariable("id") int empid)  {
		//ResponseEntity<Response> responseEntity = null;
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

		ApplicableRoles approle = (ApplicableRoles)context.getBean("ApplicableRoles");		int a;
		a = approle.getCurrentMeetingNo();
		//approle.check();
		System.out.println(a);

		List<String> rolesnotapplicable = new ArrayList<String>();
		rolesnotapplicable = approle.getPastBookings(empid,a);
		System.out.println(rolesnotapplicable);
		ListIterator<String> itr = rolesnotapplicable.listIterator();
		while(itr.hasNext()){  
		System.out.println(itr.next());  
		} 

		
		return rolesnotapplicable;

	}
	

	@ApiOperation(value = "retrieve past roles using GET method", notes = "Returns the roles details")
	@ApiParam(value = "objects that need to be invoked", required = true)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful Response", response = Response.class),
			@ApiResponse(code = 404, message = "Invalid Information Sent", response = Response.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = Response.class),
			@ApiResponse(code = 400, message = "Bad Request", response = Response.class) })

	@RequestMapping(value="bookedroles",method = RequestMethod.GET)
	public List<String> getBookedRoles()  {
		//ResponseEntity<Response> responseEntity = null;
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

		ApplicableRoles approle = (ApplicableRoles)context.getBean("ApplicableRoles");		int a;
		a = approle.getCurrentMeetingNo();
		//approle.check();
		System.out.println(a);

		List<String> rolesnotapplicable = new ArrayList<String>();
		rolesnotapplicable = approle.getBookedRoles(a);
		System.out.println(rolesnotapplicable);
		ListIterator<String> itr = rolesnotapplicable.listIterator();
		while(itr.hasNext()){  
		System.out.println(itr.next());  
		} 

		
		return rolesnotapplicable;

	}
	
	
	@ApiOperation(value = "retrieve past roles using GET method", notes = "Returns the roles details")
	@ApiParam(value = "objects that need to be invoked", required = true)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful Response", response = Response.class),
			@ApiResponse(code = 404, message = "Invalid Information Sent", response = Response.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = Response.class),
			@ApiResponse(code = 400, message = "Bad Request", response = Response.class) })

	@RequestMapping(value="meetingno",method = RequestMethod.GET)
	public int getCurrentMeetingNumber()  {
		//ResponseEntity<Response> responseEntity = null;
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

		ApplicableRoles approle = (ApplicableRoles)context.getBean("ApplicableRoles");		
		int a;
		a = approle.getCurrentMeetingNo();
		//approle.check();
		System.out.println(a);

		return a;

	}
	
	@ApiOperation(value = "retrieve past roles using GET method", notes = "Returns the roles details")
	@ApiParam(value = "objects that need to be invoked", required = true)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful Response", response = Response.class),
			@ApiResponse(code = 404, message = "Invalid Information Sent", response = Response.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = Response.class),
			@ApiResponse(code = 400, message = "Bad Request", response = Response.class) })

	@RequestMapping(value="employeeids",method = RequestMethod.GET)
	public List<Integer> getBookedEmpIds()  {
		//ResponseEntity<Response> responseEntity = null;
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

		ApplicableRoles approle = (ApplicableRoles)context.getBean("ApplicableRoles");		
		int a;
		
		a = approle.getCurrentMeetingNo();
		//approle.check();
		List<Integer> empids = new ArrayList<Integer>();
		empids = approle.getBookedEmployeeId(a);
		//System.out.println(a);

		return empids;

	}
}
