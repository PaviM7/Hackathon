package com.hackathon.bean;

import java.util.Date;

import io.swagger.annotations.ApiModelProperty;

public class AnnouncementBean {
@ApiModelProperty(position = 1, required = true, value = "represents toastMasters meeting no :meetingNo")
    

	private int meetingNo;
    @ApiModelProperty(position = 2, required = true, value = "date on which meeting is scheduled :meetingDate")

	private String meetingCommencement;
    @ApiModelProperty(position =3 , required = true, value = "time of meeting:meetingTime")

	private String meetingTime;
    @ApiModelProperty(position = 4, required = true, value = "location of meeting:meetingVenue")

	private String meetingVenue;
    @ApiModelProperty(position = 5, required = true, value = "current status of meeting:status")

	private String status;
    
    @ApiModelProperty(position = 6, required = true, value = "brief description of the property :status")

	private String theme;
	public String getTheme() {
		return theme;
	}
	public void setTheme(String theme) {
		this.theme = theme;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getMeetingNo() {
		return meetingNo;
	}
	public void setMeetingNo(int meetingNo) {
		this.meetingNo = meetingNo;
	}
	
	public String getMeetingCommencement() {
		return meetingCommencement;
	}
	public void setMeetingCommencement(String meetingCommencement) {
		this.meetingCommencement = meetingCommencement;
	}
	public String getMeetingTime() {
		return meetingTime;
	}
	public void setMeetingTime(String meetingTime) {
		this.meetingTime = meetingTime;
	}
	public String getMeetingVenue() {
		return meetingVenue;
	}
	public void setMeetingVenue(String meetingVenue) {
		this.meetingVenue = meetingVenue;
	}
}
