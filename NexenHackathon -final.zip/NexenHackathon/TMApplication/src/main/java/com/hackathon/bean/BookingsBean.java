package com.hackathon.bean;

import io.swagger.annotations.ApiModelProperty;

public class BookingsBean {
	 @ApiModelProperty(position =1 , required = true, value = "id to track the booking")

		private int id;
	    @ApiModelProperty(position = 2, required = true, value = "employee id to identify a member of the club")


	    private int employeeId;
	    @ApiModelProperty(position =3 , required = true, value = "meeting number for which the booking is to be done")

	    private int meetingNo;
	    @ApiModelProperty(position = 4, required = true, value = "role id indicates the role that is available to be booked")

		private String roleId;
	    
	    private int votes;
		public int getVotes() {
			return votes;
		}
		public void setVotes(int votes) {
			this.votes = votes;
		}
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public int getEmployeeId() {
			return employeeId;
		}
		public void setEmployeeId(int employeeId) {
			this.employeeId = employeeId;
		}
		public int getMeetingNo() {
			return meetingNo;
		}
		public void setMeetingNo(int meetingNo) {
			this.meetingNo = meetingNo;
		}
		public String getRoleId() {
			return roleId;
		}
		public void setRoleId(String roleId) {
			this.roleId = roleId;
		}
}
