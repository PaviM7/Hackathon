package com.hackathon.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.RowMapper;

import com.hackathon.bean.BookingsBean;

public class ApplicableRolesRowMapper implements RowMapper<String> {
	public String mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		// TODO Auto-generated method stub
		String rolename ;
			rolename = rs.getString(1);

		return rolename;
}
}
