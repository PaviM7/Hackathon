package com.hackathon.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.RestController;

import com.hackathon.daoimpl.BookingsDao;
import com.hackathon.model.*;
import com.hackathon.*;
import com.hackathon.bean.BookingsBean;

import io.swagger.annotations.*;


@RestController
public class BookingsController {
	@Autowired
	BookingsDao bookingsDAO;
	
	@Autowired
	MetaData metaData;

	@Autowired
	Data data;
	@Autowired
	Response response;
	

	@ApiOperation(value = "retrieve template details using GET method", notes = "Returns the template details")
	@ApiParam(value = "objects that need to be invoked", required = true)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful Response", response = Response.class),
			@ApiResponse(code = 404, message = "Invalid Information Sent", response = Response.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = Response.class),
			@ApiResponse(code = 400, message = "Bad Request", response = Response.class) })

	@RequestMapping(value="bookings",method = RequestMethod.GET, produces={MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<Response> viewBookings() throws Exception {
		ResponseEntity<Response> responseEntity = null;

		try {
			List<BookingsBean> bookingsList;

			bookingsList = bookingsDAO.getAllBookings();
			if (bookingsList.isEmpty()) {
				saveMetaData(false, "Failed", "12345");

				ErrorDetails error = new ErrorDetails();
				error.setCode("TRA2001");
				error.setDescription("Meeting details not found");
				List errors = new ArrayList();
				errors.add(error);
				saveData(error, null);
				responseEntity = new ResponseEntity<Response>(response,
						HttpStatus.NOT_FOUND);
				saveResponse(null, metaData, error);

			} else {
				saveMetaData(true, "Meetings loaded", "12345");
				saveData(null, bookingsList);
				saveResponse(data, metaData, null);

				responseEntity = new ResponseEntity<Response>(response,
						HttpStatus.OK);
			}
		} catch (Exception e) {
			saveMetaData(false, "Failed", "12345");

			ErrorDetails error = new ErrorDetails();
			error.setCode("TRA2002");

			if (e instanceof IncorrectResultSizeDataAccessException
					|| e instanceof EmptyResultDataAccessException)
				error.setDescription("Bad Request");
			else if (e instanceof DataAccessException)
				error.setDescription("Database error");
			else
				error.setDescription(e.getMessage());
			;

			saveData(error, null);
			saveResponse(null, metaData, error);

			List errors = new ArrayList();
			errors.add(error);
			responseEntity = new ResponseEntity<Response>(response,
					HttpStatus.NOT_FOUND);

		}
		return responseEntity;

	}

	
	
	@ApiOperation(value = "retrieve template details using GET method", notes = "Returns the template details")
	@ApiParam(value = "objects that need to be invoked", required = true)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful Response", response = Response.class),
			@ApiResponse(code = 404, message = "Invalid Information Sent", response = Response.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = Response.class),
			@ApiResponse(code = 400, message = "Bad Request", response = Response.class) })

	@RequestMapping(value="bookings/{id}",method = RequestMethod.GET, produces={MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<Response> viewOneBooking(@ApiParam(value = "object that need to be deleted by using one id", required = true)@PathVariable("id") int id)
	{
		
		ResponseEntity<Response> responseEntity = null;

		try {
			List<BookingsBean> BookingList;

			BookingList = bookingsDAO.getBookingById(id);
			if (BookingList.isEmpty()) {
				saveMetaData(false, "Failed", "12345");

				ErrorDetails error = new ErrorDetails();
				error.setCode("TRA2001");
				error.setDescription("Meeting details not found");
				List errors = new ArrayList();
				errors.add(error);
				saveData(error, null);
				responseEntity = new ResponseEntity<Response>(response,
						HttpStatus.NOT_FOUND);
				saveResponse(null, metaData, error);

			} else {
				saveMetaData(true, "Meetings loaded", "12345");
				saveData(null, BookingList);
				saveResponse(data, metaData, null);

				responseEntity = new ResponseEntity<Response>(response,
						HttpStatus.OK);
			}
		} catch (Exception e) {
			saveMetaData(false, "Failed", "12345");

			ErrorDetails error = new ErrorDetails();
			error.setCode("TRA2002");

			if (e instanceof IncorrectResultSizeDataAccessException
					|| e instanceof EmptyResultDataAccessException)
				error.setDescription("Bad Request");
			else if (e instanceof DataAccessException)
				error.setDescription("Database error");
			else
				error.setDescription(e.getMessage());
			;

			saveData(error, null);
			saveResponse(null, metaData, error);

			List errors = new ArrayList();
			errors.add(error);
			responseEntity = new ResponseEntity<Response>(response,
					HttpStatus.NOT_FOUND);

		}
		return responseEntity;

}
	
	
	
	@ApiOperation(value = "inserts user record", notes = "Returns the status of insertion")
	@ApiParam(value = "single record to be inserted", required = true)
	@ApiResponses(value = {
			@ApiResponse(code = 405, message = "Method Not Supported", response = Response.class),
			@ApiResponse(code = 201, message = "Successful ", response = Response.class),
			@ApiResponse(code = 404, message = "Invalid Information Sent", response = Response.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = Response.class),
			@ApiResponse(code = 400, message = "Bad Request") })
	
	@RequestMapping(value="bookings", method = RequestMethod.POST, consumes=MediaType.APPLICATION_JSON_VALUE, produces={MediaType.APPLICATION_JSON_VALUE})
	@ResponseStatus(value = HttpStatus.CREATED)
	public ResponseEntity<Response> insertBookings(@RequestBody BookingsBean booking) {
	

		ResponseEntity<Response> responseEntity = null;
		try {
			System.out.println(booking.getVotes());
			
			if(booking.getId()!=0&&booking.getEmployeeId()!=0&&booking.getMeetingNo()!=0&&booking.getRoleId()!=null && booking.getVotes()==0){
			
			System.out.println("inside if");
			
				BookingsBean bookingBean = bookingsDAO.bookRole(booking);
				ArrayList<BookingsBean> bookingList = new ArrayList<BookingsBean>();
				bookingList.add(bookingBean);

				if (bookingBean!=null) {

					saveMetaData(true, "Record Created", "12348");
					saveData(null, bookingList);
					saveResponse(data, metaData, null);

					responseEntity = new ResponseEntity<Response>(response,
							HttpStatus.OK);

				}

				else {

					ErrorDetails error = new ErrorDetails();
					error.setCode("TRA2013");
					error.setDescription("Unable to insert the record");
					List errors = new ArrayList();
					errors.add(error);

					saveData(error, null);
					saveMetaData(false, "Record Not Created", "14333");
					saveResponse(null, metaData, error);
					responseEntity = new ResponseEntity<Response>(response,
							HttpStatus.NOT_FOUND);

				

			}
			}
			else
			{
				ErrorDetails error = new ErrorDetails();
				error.setCode("TRA2014");
				error.setDescription("The required parameters missing");
				List errors = new ArrayList();
				errors.add(error);

				saveData(error, null);
				saveMetaData(false, "Record Not Created", "14333");
				saveResponse(null, metaData, error);
				responseEntity = new ResponseEntity<Response>(response,
						HttpStatus.NOT_FOUND);
			}
		}

		catch (Exception e) {

			ErrorDetails error = new ErrorDetails();
			error.setCode("TRA2014");

			if (e instanceof IncorrectResultSizeDataAccessException
					|| e instanceof EmptyResultDataAccessException)
				error.setDescription("Bad Request");
			else if (e instanceof DataAccessException)
				error.setDescription("Database error");
			else
				error.setDescription(e.getMessage());
			
			saveMetaData(false, "Error Occured", "respId12345");
			saveData(error, null);
			saveResponse(null, metaData, error);

			List errors = new ArrayList();
			errors.add(error);
			responseEntity = new ResponseEntity<Response>(response,
					HttpStatus.BAD_REQUEST);

		}
		return responseEntity;

	}

	
	
	@ApiOperation(value = "updates the users credits with PUT method", notes = "Returns the updated user record")
	@ApiParam(value = "object that need to be updated by using one id", required = true)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful Response", response = Response.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = Response.class),
			@ApiResponse(code = 400, message = "Bad Request", response = Response.class) })
	
	@RequestMapping(value="bookings/{id}", method = RequestMethod.PUT, consumes=MediaType.APPLICATION_JSON_VALUE, produces={MediaType.APPLICATION_JSON_VALUE})
	@ResponseStatus(value = HttpStatus.CREATED)
	public ResponseEntity<Response> updateBookings(
			@ApiParam(value = "object that need to be deleted by using one id", required = true) @PathVariable("id") int id,@RequestBody BookingsBean booking) {

		List<BookingsBean> list = new ArrayList<BookingsBean>();

		ResponseEntity<Response> responseEntity = null;
		try {
			
				int n = bookingsDAO.updateBooking(id,booking);
				if (n == 1) {
				
					List<BookingsBean> bookingList = bookingsDAO.getBookingById(id);
					 
					
					//String s = new String("Successfully Updated");
					saveMetaData(true, "Record Updated", "14359");
					saveData(null,bookingList);
					saveResponse(data, metaData, null);

					responseEntity = new ResponseEntity<Response>(response,
							HttpStatus.OK);

				}

				else {
					ErrorDetails error = new ErrorDetails();
					error.setCode("TRA2009");
					error.setDescription("The user with the specified id is not found");
					List errors = new ArrayList();
					errors.add(error);
					saveMetaData(false, "Record not Updated", "12345");
					saveData(error, null);
					saveResponse(null, metaData, error);

					responseEntity = new ResponseEntity<Response>(response,
							HttpStatus.NOT_FOUND);

				}
			 
		} catch (Exception e) {
			saveMetaData(false, "Failed", "12345");

			ErrorDetails error = new ErrorDetails();
			error.setCode("TRA2011");

			if (e instanceof IncorrectResultSizeDataAccessException
					|| e instanceof EmptyResultDataAccessException)
				error.setDescription("Bad Request");
			else if (e instanceof DataAccessException)
				error.setDescription("Database error");
			else
				error.setDescription(e.getMessage());
			;
			saveMetaData(false, "Error Occured", "respId12345");
			saveData(error, null);
			saveResponse(null, metaData, error);

			List errors = new ArrayList();
			errors.add(error);
			responseEntity = new ResponseEntity<Response>(response,
					HttpStatus.NOT_FOUND);

		}

		return responseEntity;

	}
	
	
	@ApiOperation(value = "delete the template record with DELETE method", notes = "Returns the deleted template record")
	@ApiParam(value = "object that need to be deleted by using one id", required = true)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful Response", response = Response.class),
			@ApiResponse(code = 404, message = "Invalid Information Sent", response = Response.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = Response.class),
			@ApiResponse(code = 400, message = "Bad Request", response = Response.class),
			@ApiResponse(code = 405, message = "Method not Supported", response = Response.class)})
	
	@RequestMapping(value = "bookings/{id}", method = RequestMethod.DELETE, produces = { MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<Response> removebookingouncement(
			@ApiParam(value = "object that need to be deleted by using one id", required = true)@PathVariable("id") int id) {
	
		ResponseEntity<Response> responseEntity = null;
		try {
			
				List<BookingsBean> bookingList = new ArrayList<BookingsBean>();

				bookingList = bookingsDAO.getBookingById(id);
				int n = bookingsDAO.removeBooking(id);

				if (n == 1) {
					//String s = new String("Deletion Successful");
					saveMetaData(true, "Record deleted", "14358");
					saveData(null, bookingList);
					saveResponse(data, metaData, null);
					responseEntity = new ResponseEntity<Response>(response,
							HttpStatus.OK);

				} else {
					ErrorDetails error = new ErrorDetails();
					error.setCode("TRA2006");
					error.setDescription("No such template");
					List errors = new ArrayList();
					errors.add(error);
					saveMetaData(false, "No such record", "12345");
					saveData(error, null);
					saveResponse(data, metaData, null);

					responseEntity = new ResponseEntity<Response>(response,
							HttpStatus.NOT_FOUND);

				
			} 
			} catch (Exception e) {
			saveMetaData(false, "Failed", "12347");

			ErrorDetails error = new ErrorDetails();
			error.setCode("TRA2008");

			if (e instanceof IncorrectResultSizeDataAccessException
					|| e instanceof EmptyResultDataAccessException)
				error.setDescription("Bad Request");
			else if (e instanceof DataAccessException)
				error.setDescription("Database error");
			else
				error.setDescription(e.getMessage());
			;
			saveMetaData(false, "Error Occured", "respId12345");
			saveData(error, null);
			saveResponse(null, metaData, error);

			List errors = new ArrayList();
			errors.add(error);
			responseEntity = new ResponseEntity<Response>(response,
					HttpStatus.NOT_FOUND);
			saveResponse(null, metaData, error);

		}
		return responseEntity;
				
			} 
	
	
	@ApiOperation(value = "retrieve template details using GET method", notes = "Returns the template details")
	@ApiParam(value = "objects that need to be invoked", required = true)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful Response", response = Response.class),
			@ApiResponse(code = 404, message = "Invalid Information Sent", response = Response.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = Response.class),
			@ApiResponse(code = 400, message = "Bad Request", response = Response.class) })

	@RequestMapping(value="bookings/{id}/{mno}",method = RequestMethod.GET, produces={MediaType.APPLICATION_JSON_VALUE})
	public String viewMyBooking(@ApiParam(value = "object that need to be deleted by using one id", required = true)@PathVariable("id") int id, @ApiParam(value = "object that need to be deleted by using one id", required = true)@PathVariable("mno") int meetingno)
	{
		
		ResponseEntity<Response> responseEntity = null;

		
			String rolename = null;

			try {
				rolename = bookingsDAO.getMyCurrentBooking(id, meetingno);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(rolename);
return rolename;
}

	private void saveResponse(Data data, MetaData metaData,
			ErrorDetails errorDet) {
		response.setData(data);
		response.setMetaData(metaData);
		response.setError(errorDet);
	}

	private void saveData(ErrorDetails erroDet, List testObj) {
		response.setError(erroDet);
		data.setOutput(testObj);

	}

	private void saveMetaData(boolean success, String description,
			String responseId) {

		metaData.setSuccess(success);
		metaData.setDescription(description);
		metaData.setResponseId(responseId);
	}
}
