package com.hackathon.daoimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;

import com.hackathon.bean.BookingsBean;
import com.hackathon.dao.IBookingsDAO;
import com.hackathon.rowmapper.BookingRowMapper;
import com.hackathon.rowmapper.CurrentBookedRoleRowMapper;

@Component
public class BookingsDao extends JdbcDaoSupport implements IBookingsDAO {
	
	@Autowired
	public BookingsDao(DataSource dataSource) {
		// TODO Auto-generated constructor stub
		setDataSource(dataSource);
	}

	@Autowired
private Properties queryProps;
	
	public Properties getQueryProps() {
		return queryProps;
	}

	public void setQueryProps(Properties queryProps) {
		this.queryProps = queryProps;
	}

	public List<BookingsBean> getAllBookings() throws Exception {
		// TODO Auto-generated method stub
		String sql = queryProps.getProperty("getBookings");
		System.out.println(sql);
		List<BookingsBean> bookingList = new ArrayList<BookingsBean>();
		bookingList = getJdbcTemplate().query(sql,new Object[] {},new BookingRowMapper());
		return bookingList;
	}

	public BookingsBean bookRole(BookingsBean bookingsBean) throws Exception {
		// TODO Auto-generated method stub
		int numrows = 0;
		String SQL1 = queryProps.getProperty("setBooking");
		System.out.println(numrows);
		try{
		numrows = getJdbcTemplate().update(SQL1,new Object[]{bookingsBean.getId(),bookingsBean.getEmployeeId(),bookingsBean.getMeetingNo(),bookingsBean.getRoleId(),bookingsBean.getVotes()});
		System.out.println(numrows);
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		return( numrows == 1 ?  bookingsBean: null);
	}

	public int removeBooking(int id) throws Exception {
		// TODO Auto-generated method stub
		String SQL1 = queryProps.getProperty("deleteBooking");
		BookingsBean bookingBean = new BookingsBean();
		bookingBean.setId(id);

		int a = getJdbcTemplate().update(SQL1, new Object[]{bookingBean.getId()});
		
		return a;
	}

	public int updateBooking(int id, BookingsBean bookingBean) throws Exception {
		// TODO Auto-generated method stub
		String SQL1 = queryProps.getProperty("updatebooking");
		bookingBean.setId(id);
				int a=getJdbcTemplate().update(SQL1,new Object[]{bookingBean.getEmployeeId(),bookingBean.getMeetingNo(),bookingBean.getRoleId(),bookingBean.getId()});
				return a;
	}

	public List<BookingsBean> getBookingById(int bookingId) throws Exception {
		// TODO Auto-generated method stub
		String sql = queryProps.getProperty("getOneBooking");
		BookingsBean bookingBean = new BookingsBean();
		
		bookingBean.setId(bookingId);
		List<BookingsBean> bookingList = new ArrayList<BookingsBean>();
		bookingList = getJdbcTemplate().query(sql,new Object[] {bookingBean.getId()},new BookingRowMapper());
		return bookingList;
	}

	public String getMyCurrentBooking(int employeeid, int meetingno) throws Exception {
		// TODO Auto-generated method stub
		String sql = "select T_XBBNHCJ_ROLES.rolename from T_XBBNHCJ_ROLES  inner join  T_XBBNHCJ_BOOKINGS on T_XBBNHCJ_BOOKINGS.rolename = T_XBBNHCJ_ROLES.roleid where T_XBBNHCJ_BOOKINGS.meetingno = ? and T_XBBNHCJ_BOOKINGS.employeeid = ?";
		//BookingsBean bookingBean = new BookingsBean();
		
		String rolename;
		//List<BookingsBean> bookingList = new ArrayList<BookingsBean>();
		rolename = getJdbcTemplate().queryForObject(sql,new Object[] {meetingno,employeeid}, String.class);
	
		return rolename;
	}
}
