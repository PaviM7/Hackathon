package com.hackathon.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.TypeMismatchException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.hackathon.daoimpl.AnnouncementDao;
import com.hackathon.model.Data;
import com.hackathon.model.ErrorDetails;
import com.hackathon.model.MetaData;
import com.hackathon.model.Response;

import io.swagger.annotations.*;

import com.hackathon.bean.*;

@RestController

public class AnnouncementController {
	@Autowired
	AnnouncementDao announcementDAO;
	
	@Autowired
	MetaData metaData;

	@Autowired
	Data data;
	@Autowired
	Response response;
	
	@ApiOperation(value = "retrieve announcement details using GET method", notes = "Returns the announcement details")
	@ApiParam(value = "objects that need to be invoked", required = true)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful Response", response = Response.class),
			@ApiResponse(code = 404, message = "Invalid Information Sent", response = Response.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = Response.class),
			@ApiResponse(code = 400, message = "Bad Request", response = Response.class) })

	@RequestMapping(value="announcements",method = RequestMethod.GET, produces={MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<Response> viewAnnouncement() throws Exception {
		ResponseEntity<Response> responseEntity = null;

		try {
			List<AnnouncementBean> announcementList;

			announcementList = announcementDAO.getAllMeetings();
			if (announcementList.isEmpty()) {
				saveMetaData(false, "Failed", "12345");

				ErrorDetails error = new ErrorDetails();
				error.setCode("TRA2001");
				error.setDescription("Meeting details not found");
				List errors = new ArrayList();
				errors.add(error);
				saveData(error, null);
				responseEntity = new ResponseEntity<Response>(response,
						HttpStatus.NOT_FOUND);
				saveResponse(null, metaData, error);

			} else {
				saveMetaData(true, "Meetings loaded", "12345");
				saveData(null, announcementList);
				saveResponse(data, metaData, null);

				responseEntity = new ResponseEntity<Response>(response,
						HttpStatus.OK);
			}
		} catch (Exception e) {
			saveMetaData(false, "Failed", "12345");

			ErrorDetails error = new ErrorDetails();
			error.setCode("TRA2002");

			if (e instanceof IncorrectResultSizeDataAccessException
					|| e instanceof EmptyResultDataAccessException)
				error.setDescription("Bad Request");
			else if (e instanceof DataAccessException)
				error.setDescription("Database error");
			else
				error.setDescription(e.getMessage());
			;

			saveData(error, null);
			saveResponse(null, metaData, error);

			List errors = new ArrayList();
			errors.add(error);
			responseEntity = new ResponseEntity<Response>(response,
					HttpStatus.NOT_FOUND);

		}
		return responseEntity;

	}

	
	
	@ApiOperation(value = "retrieves specific announcement details using GET method", notes = "Returns the specific meeting details")
	@ApiParam(value = "objects that need to be invoked", required = true)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful Response", response = Response.class),
			@ApiResponse(code = 404, message = "Invalid Information Sent", response = Response.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = Response.class),
			@ApiResponse(code = 400, message = "Bad Request", response = Response.class) })

	@RequestMapping(value="announcements/{id}",method = RequestMethod.GET, produces={MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<Response> viewOneannouncement(@ApiParam(value = "object that need to be deleted by using one id", required = true)@PathVariable("id") String status)
	{
		
		ResponseEntity<Response> responseEntity = null;

		try {
			List<AnnouncementBean> announcementList;

			announcementList = announcementDAO.getMeetingById(status);
			if (announcementList.isEmpty()) {
				saveMetaData(false, "Failed", "12345");

				ErrorDetails error = new ErrorDetails();
				error.setCode("TRA2001");
				error.setDescription("Meeting details not found");
				List errors = new ArrayList();
				errors.add(error);
				saveData(error, null);
				responseEntity = new ResponseEntity<Response>(response,
						HttpStatus.NOT_FOUND);
				saveResponse(null, metaData, error);

			} else {
				saveMetaData(true, "Meetings loaded", "12345");
				saveData(null, announcementList);
				saveResponse(data, metaData, null);

				responseEntity = new ResponseEntity<Response>(response,
						HttpStatus.OK);
			}
		} catch (Exception e) {
			saveMetaData(false, "Failed", "12345");

			ErrorDetails error = new ErrorDetails();
			error.setCode("TRA2002");

			if (e instanceof IncorrectResultSizeDataAccessException
					|| e instanceof EmptyResultDataAccessException)
				error.setDescription("Bad Request");
			else if (e instanceof DataAccessException)
				error.setDescription("Database error");
			else
				error.setDescription(e.getMessage());
			;

			saveData(error, null);
			saveResponse(null, metaData, error);

			List errors = new ArrayList();
			errors.add(error);
			responseEntity = new ResponseEntity<Response>(response,
					HttpStatus.NOT_FOUND);

		}
		return responseEntity;

}
	
	
	
	@ApiOperation(value = "inserts meeting details record", notes = "Returns the status of insertion")
	@ApiParam(value = "single record to be inserted", required = true)
	@ApiResponses(value = {
			@ApiResponse(code = 405, message = "Method Not Supported", response = Response.class),
			@ApiResponse(code = 201, message = "Successful ", response = Response.class),
			@ApiResponse(code = 404, message = "Invalid Information Sent", response = Response.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = Response.class),
			@ApiResponse(code = 400, message = "Bad Request") })
	
	@RequestMapping(value="announcements", method = RequestMethod.POST, consumes=MediaType.APPLICATION_JSON_VALUE, produces={MediaType.APPLICATION_JSON_VALUE})
	@ResponseStatus(value = HttpStatus.CREATED)
	public ResponseEntity<Response> insertAnnouncement(@RequestBody AnnouncementBean announcement) {
	System.out.println("Inside post");

		ResponseEntity<Response> responseEntity = null;
		try {
			if(announcement.getMeetingNo()!=0&&announcement.getMeetingCommencement()!=null&&announcement.getMeetingTime()!=null&&announcement.getMeetingVenue()!=null){
			
				System.out.println("Inside post if");

			
				AnnouncementBean announcementBean = announcementDAO.newMeeting(announcement);
				ArrayList<AnnouncementBean> announcementList = new ArrayList<AnnouncementBean>();
				announcementList.add(announcementBean);
				System.out.println(announcementBean);

				if (announcementBean!=null) {

					saveMetaData(true, "Record Created", "12348");
					saveData(null, announcementList);
					saveResponse(data, metaData, null);

					responseEntity = new ResponseEntity<Response>(response,
							HttpStatus.OK);

				}

				else {

					ErrorDetails error = new ErrorDetails();
					error.setCode("TRA2013");
					error.setDescription("Unable to insert the record");
					List errors = new ArrayList();
					errors.add(error);

					saveData(error, null);
					saveMetaData(false, "Record Not Created", "14333");
					saveResponse(null, metaData, error);
					responseEntity = new ResponseEntity<Response>(response,
							HttpStatus.NOT_FOUND);

				

			}
			}
			else
			{
				ErrorDetails error = new ErrorDetails();
				error.setCode("TRA2014");
				error.setDescription("The required parameters missing");
				List errors = new ArrayList();
				errors.add(error);

				saveData(error, null);
				saveMetaData(false, "Record Not Created", "14333");
				saveResponse(null, metaData, error);
				responseEntity = new ResponseEntity<Response>(response,
						HttpStatus.NOT_FOUND);
			}
		}

		catch (Exception e) {

			ErrorDetails error = new ErrorDetails();
			error.setCode("TRA2014");

			if (e instanceof IncorrectResultSizeDataAccessException
					|| e instanceof EmptyResultDataAccessException)
				error.setDescription("Bad Request");
			else if (e instanceof DataAccessException)
			{
				System.out.println(e.getMessage());

				error.setDescription("Database error");
				
			}
			else
				error.setDescription(e.getMessage());
			
			saveMetaData(false, "Error Occured", "respId12345");
			saveData(error, null);
			saveResponse(null, metaData, error);

			List errors = new ArrayList();
			errors.add(error);
			responseEntity = new ResponseEntity<Response>(response,
					HttpStatus.BAD_REQUEST);

		}
		return responseEntity;

	}

	
	
	@ApiOperation(value = "updates meeting details with PUT method", notes = "Returns the updated meeting record")
	@ApiParam(value = "object that need to be updated by using one id", required = true)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful Response", response = Response.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = Response.class),
			@ApiResponse(code = 400, message = "Bad Request", response = Response.class) })
	
	@RequestMapping(value="announcements/{id}", method = RequestMethod.PUT, consumes=MediaType.APPLICATION_JSON_VALUE, produces={MediaType.APPLICATION_JSON_VALUE})
	@ResponseStatus(value = HttpStatus.CREATED)
	public ResponseEntity<Response> updateAnnouncement(
			@ApiParam(value = "object that need to be deleted by using one id", required = true) @PathVariable("id") int meetingNo,@RequestBody AnnouncementBean announcement) {

		List<AnnouncementBean> list = new ArrayList<AnnouncementBean>();

		ResponseEntity<Response> responseEntity = null;
		try {
			
				int n = announcementDAO.updateMeeting(meetingNo,announcement);
				if (n == 1) {
				
					List<AnnouncementBean> annList = announcementDAO.getAllMeetings();
					 
					
					String s = new String("Successfully Updated");
					saveMetaData(true, "Record Updated", "14359");
					saveData(null, annList);
					saveResponse(data, metaData, null);

					responseEntity = new ResponseEntity<Response>(response,
							HttpStatus.OK);

				}

				else {
					ErrorDetails error = new ErrorDetails();
					error.setCode("TRA2009");
					error.setDescription("The meeting detail with the specified id is not found");
					List errors = new ArrayList();
					errors.add(error);
					saveMetaData(false, "Record not Updated", "12345");
					saveData(error, null);
					saveResponse(null, metaData, error);

					responseEntity = new ResponseEntity<Response>(response,
							HttpStatus.NOT_FOUND);

				}
			 
		} catch (Exception e) {
			saveMetaData(false, "Failed", "12345");

			ErrorDetails error = new ErrorDetails();
			error.setCode("TRA2011");

			if (e instanceof IncorrectResultSizeDataAccessException
					|| e instanceof EmptyResultDataAccessException)
				error.setDescription("Bad Request");
			else if (e instanceof DataAccessException)
				error.setDescription("Database error");
			else
				error.setDescription(e.getMessage());
			;
			saveMetaData(false, "Error Occured", "respId12345");
			saveData(error, null);
			saveResponse(null, metaData, error);

			List errors = new ArrayList();
			errors.add(error);
			responseEntity = new ResponseEntity<Response>(response,
					HttpStatus.NOT_FOUND);

		}

		return responseEntity;

	}
	
	
	@ApiOperation(value = "delete the meeting detail record with DELETE method", notes = "Returns the deleted record")
	@ApiParam(value = "object that need to be deleted by using one id", required = true)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful Response", response = Response.class),
			@ApiResponse(code = 404, message = "Invalid Information Sent", response = Response.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = Response.class),
			@ApiResponse(code = 400, message = "Bad Request", response = Response.class),
			@ApiResponse(code = 405, message = "Method not Supported", response = Response.class)})
	
	@RequestMapping(value = "announcements/{id}", method = RequestMethod.DELETE, produces = { MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<Response> removeAnnouncement(
			@ApiParam(value = "object that need to be deleted by using one id", required = true)@PathVariable("id") int id) {
	
		ResponseEntity<Response> responseEntity = null;
		try {
			
				List<AnnouncementBean> annList = new ArrayList<AnnouncementBean>();

				annList = announcementDAO.getMeetingById(id);
				int n = announcementDAO.removeMeeting(id);

				if (n == 1) {
					//String s = new String("Deletion Successful");
					saveMetaData(true, "Record deleted", "14358");
					saveData(null, annList);
					saveResponse(data, metaData, null);
					responseEntity = new ResponseEntity<Response>(response,
							HttpStatus.OK);

				} else {
					ErrorDetails error = new ErrorDetails();
					error.setCode("TRA2006");
					error.setDescription("No such record");
					List errors = new ArrayList();
					errors.add(error);
					saveMetaData(false, "No such record", "12345");
					saveData(error, null);
					saveResponse(data, metaData, null);

					responseEntity = new ResponseEntity<Response>(response,
							HttpStatus.NOT_FOUND);

				
			} 
			} catch (Exception e) {
			saveMetaData(false, "Failed", "12347");

			ErrorDetails error = new ErrorDetails();
			error.setCode("TRA2008");

			if (e instanceof IncorrectResultSizeDataAccessException
					|| e instanceof EmptyResultDataAccessException)
				error.setDescription("Bad Request");
			else if (e instanceof DataAccessException)
				error.setDescription("Database error");
			else
				error.setDescription(e.getMessage());
			;
			saveMetaData(false, "Error Occured", "respId12345");
			saveData(error, null);
			saveResponse(null, metaData, error);

			List errors = new ArrayList();
			errors.add(error);
			responseEntity = new ResponseEntity<Response>(response,
					HttpStatus.NOT_FOUND);
			saveResponse(null, metaData, error);

		}
		return responseEntity;
				
			} 

	private void saveResponse(Data data, MetaData metaData,
			ErrorDetails errorDet) {
		response.setData(data);
		response.setMetaData(metaData);
		response.setError(errorDet);
	}

	private void saveData(ErrorDetails erroDet, List testObj) {
		response.setError(erroDet);
		data.setOutput(testObj);

	}

	private void saveMetaData(boolean success, String description,
			String responseId) {

		metaData.setSuccess(success);
		metaData.setDescription(description);
		metaData.setResponseId(responseId);
	}
	@ExceptionHandler(TypeMismatchException.class)
	public @ResponseBody ResponseEntity<Object> typeMismatchExpcetionHandler(
			Exception exception, HttpServletRequest request) {
		ErrorDetails error = new ErrorDetails();
		error.setCode("TRA1001");
		error.setDescription("The Id must be of Integer type-Input Parameter type mismatch");
		ResponseEntity<Object> responseEntity = new ResponseEntity<Object>(
				error, HttpStatus.BAD_REQUEST);

		return responseEntity;
	}

	@ExceptionHandler(MissingServletRequestParameterException.class)
	public @ResponseBody ResponseEntity<Object> missingParameterExpcetionHandler(
			Exception exception, HttpServletRequest request) {
		ErrorDetails error = new ErrorDetails();
		error.setCode("TRA1002");
		error.setDescription("The parameter is missing in the request-Missing Parameter");
		ResponseEntity<Object> responseEntity = new ResponseEntity<Object>(
				error, HttpStatus.BAD_REQUEST);

		return responseEntity;
	}
	/*@ExceptionHandler(MethodArgumentNotValidException.class)
	public @ResponseBody ResponseEntity<Object> argumentMismatch(
			Exception exception, HttpServletRequest request) {
		ErrorDetails error = new ErrorDetails();
		error.setCode("TRA1002");
		error.setDescription("The parameter is missing in the request-Missing Parameter");
		ResponseEntity<Object> responseEntity = new ResponseEntity<Object>(
				error, HttpStatus.BAD_REQUEST);

		return responseEntity;
	}*/

	@ExceptionHandler(HttpRequestMethodNotSupportedException.class)
	public @ResponseBody ResponseEntity<Object> handleError405(Exception e,
			HttpServletRequest request) {
		ErrorDetails error = new ErrorDetails();
		error.setCode("TRA1003");
		System.out.println("hi");
		error.setDescription("The specified HTTP method is not allowed for the requested resource-check the request url for the required resource with HTTP method");
		ResponseEntity<Object> responseEntity = new ResponseEntity<Object>(
				error, HttpStatus.BAD_REQUEST);

		return responseEntity;
	}

	@ExceptionHandler(Exception.class)
	public @ResponseBody ResponseEntity<Object> generalExceptionHandler(
			Exception exception, HttpServletRequest request) {
		ErrorDetails error = new ErrorDetails();
		error.setCode("TRA1004");
		error.setDescription("Bad Request");
		System.out.println("hi");
		ResponseEntity<Object> responseEntity = new ResponseEntity<Object>(
				error, HttpStatus.BAD_REQUEST);

		return responseEntity;
	}

}
