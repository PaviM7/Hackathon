package com.hackathon.daoimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.hackathon.bean.BookingsBean;
import com.hackathon.rowmapper.ApplicableRolesRowMapper;
import com.hackathon.rowmapper.BookedIdsRowMapper;
import com.hackathon.rowmapper.BookingRowMapper;

public class ApplicableRoles extends JdbcDaoSupport{
	
	private int meetingno;
	
	@Autowired
	public ApplicableRoles(DataSource dataSource) {
		// TODO Auto-generated constructor stub
		setDataSource(dataSource);
	}
	
	public ApplicableRoles() {
		// TODO Auto-generated constructor stub
		
	}
	
	
	@Autowired
	private Properties queryProps;
		
		public Properties getQueryProps() {
			return queryProps;
		}

		public void setQueryProps(Properties queryProps) {
			this.queryProps = queryProps;
		}
		
		public int getCurrentMeetingNo ()
		{
			//List<String> roleslist = new ArrayList<String>();
			String sql = "SELECT meetingno FROM T_XBBNHC9_MeetingDetails where status='forth coming'";
			meetingno = getJdbcTemplate().queryForObject(sql,new Object[] {}, Integer.class);
			System.out.println(meetingno);
			return meetingno ;
			
		}
		
		/*public void check()
		{
			System.out.println(meetingno);
		}
		select employeeid from T_XBBNHCJ_BOOKINGS where meetingno = ?
	
*/
		public List<String> getPastBookings(int empid , int currentno)
		{
			List<String> rolesnotapplicable = new ArrayList<String>();
			String sql = "select rolename from T_XBBNHCJ_BOOKINGS where employeeid = ? and (meetingno = ? or meetingno = ? or meetingno = ?)";
			rolesnotapplicable = getJdbcTemplate().query(sql,new Object[] {empid , currentno-1, currentno-2, currentno-3},new ApplicableRolesRowMapper());
			return rolesnotapplicable;
		}
		
		public List<String> getBookedRoles(int currentno)
		{
			List<String> rolesnotapplicable = new ArrayList<String>();
			String sql = "select rolename from T_XBBNHCJ_BOOKINGS where meetingno=?";
			rolesnotapplicable = getJdbcTemplate().query(sql,new Object[] {currentno},new ApplicableRolesRowMapper());
			return rolesnotapplicable;
		}
		
	public List<Integer> getBookedEmployeeId(int a)
		{
			List<Integer> bookedempids = new ArrayList<Integer>();
			String sql = "select employeeid from T_XBBNHCJ_BOOKINGS where meetingno = ?";
			
			bookedempids = getJdbcTemplate().query(sql,new Object[] {a},new BookedIdsRowMapper());
			System.out.println(bookedempids);
			return bookedempids;
		}
}

