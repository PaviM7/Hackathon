package com.hackathon.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.jdbc.core.RowMapper;

import com.hackathon.bean.AnnouncementBean;

public class AnnouncementRowMapper implements RowMapper<AnnouncementBean> {

	public AnnouncementBean mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
AnnouncementBean announcementObj = new AnnouncementBean();
		
		
		Date date  = new Date(rs.getDate(2).getTime());
		//Date date = new Date(rs.getDate(1));
		//java.sql.Date  date  = new Date(rs.getDate(1));
		announcementObj.setMeetingNo(rs.getInt(1));
		
		announcementObj.setMeetingCommencement(new SimpleDateFormat("yyyy-MM-dd").format(date));
		 //DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd");
         
         //to convert Date to String, use format method of SimpleDateFormat class.
       // announcementObj.setStr(dateFormat.format(date));
		

		announcementObj.setMeetingTime(rs.getString(3));
		

		announcementObj.setMeetingVenue(rs.getString(4));
		announcementObj.setStatus(rs.getString(5));
		announcementObj.setTheme(rs.getString(6));

		return announcementObj;
	
	}
	}


