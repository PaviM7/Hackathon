package com.hackathon.model;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.hackathon.daoimpl.ApplicableRoles;

public class Main {

	private static  int a;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

		ApplicableRoles approle = (ApplicableRoles)context.getBean("ApplicableRoles");
		;

a = approle.getCurrentMeetingNo();
//approle.check();
System.out.println(a);

List<String> rolesnotapplicable = new ArrayList<String>();
rolesnotapplicable = approle.getPastBookings(12345,a);
System.out.println(rolesnotapplicable);
ListIterator<String> itr = rolesnotapplicable.listIterator();
while(itr.hasNext()){  
System.out.println(itr.next());  
} 
	}

}
