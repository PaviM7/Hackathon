package com.hackathon.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.*;

import com.hackathon.bean.RolesBean;
import com.hackathon.daoimpl.RolesDao;
import com.hackathon.model.*;
import com.hackathon.model.ErrorDetails;
import com.hackathon.model.MetaData;
import com.hackathon.model.Response;

import io.swagger.annotations.*;


@RestController

public class RolesController {
	@Autowired
	RolesDao rolesDAO;
	
	@Autowired
	MetaData metaData;

	@Autowired
	Data data;
	@Autowired
	Response response;
	

	@ApiOperation(value = "retrieve template details using GET method", notes = "Returns the template details")
	@ApiParam(value = "objects that need to be invoked", required = true)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful Response", response = Response.class),
			@ApiResponse(code = 404, message = "Invalid Information Sent", response = Response.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = Response.class),
			@ApiResponse(code = 400, message = "Bad Request", response = Response.class) })

	@RequestMapping(value="roles",method = RequestMethod.GET, produces={MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<Response> viewRoles() throws Exception {
		ResponseEntity<Response> responseEntity = null;

		try {
			List<RolesBean> rolesList;

			rolesList = rolesDAO.getAllRoles();
			if (rolesList.isEmpty()) {
				saveMetaData(false, "Failed", "12345");

				ErrorDetails error = new ErrorDetails();
				error.setCode("TRA2001");
				error.setDescription("Meeting details not found");
				List errors = new ArrayList();
				errors.add(error);
				saveData(error, null);
				responseEntity = new ResponseEntity<Response>(response,
						HttpStatus.NOT_FOUND);
				saveResponse(null, metaData, error);

			} else {
				saveMetaData(true, "Meetings loaded", "12345");
				saveData(null, rolesList);
				saveResponse(data, metaData, null);

				responseEntity = new ResponseEntity<Response>(response,
						HttpStatus.OK);
			}
		} catch (Exception e) {
			saveMetaData(false, "Failed", "12345");

			ErrorDetails error = new ErrorDetails();
			error.setCode("TRA2002");

			if (e instanceof IncorrectResultSizeDataAccessException
					|| e instanceof EmptyResultDataAccessException)
				error.setDescription("Bad Request");
			else if (e instanceof DataAccessException)
				error.setDescription("Database error");
			else
				error.setDescription(e.getMessage());
			;

			saveData(error, null);
			saveResponse(null, metaData, error);

			List errors = new ArrayList();
			errors.add(error);
			responseEntity = new ResponseEntity<Response>(response,
					HttpStatus.NOT_FOUND);

		}
		return responseEntity;

	}

	
	
	@ApiOperation(value = "retrieve template details using GET method", notes = "Returns the template details")
	@ApiParam(value = "objects that need to be invoked", required = true)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful Response", response = Response.class),
			@ApiResponse(code = 404, message = "Invalid Information Sent", response = Response.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = Response.class),
			@ApiResponse(code = 400, message = "Bad Request", response = Response.class) })

	@RequestMapping(value="roles/{id}",method = RequestMethod.GET, produces={MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<Response> viewOneRole(@ApiParam(value = "object that need to be deleted by using one id", required = true)@PathVariable("id") String id)
	{
		
		ResponseEntity<Response> responseEntity = null;

		try {
			List<RolesBean> roleList;

			roleList = rolesDAO.getRoleById(id);
			if (roleList.isEmpty()) {
				saveMetaData(false, "Failed", "12345");

				ErrorDetails error = new ErrorDetails();
				error.setCode("TRA2001");
				error.setDescription("Meeting details not found");
				List errors = new ArrayList();
				errors.add(error);
				saveData(error, null);
				responseEntity = new ResponseEntity<Response>(response,
						HttpStatus.NOT_FOUND);
				saveResponse(null, metaData, error);

			} else {
				saveMetaData(true, "Meetings loaded", "12345");
				saveData(null, roleList);
				saveResponse(data, metaData, null);

				responseEntity = new ResponseEntity<Response>(response,
						HttpStatus.OK);
			}
		} catch (Exception e) {
			saveMetaData(false, "Failed", "12345");

			ErrorDetails error = new ErrorDetails();
			error.setCode("TRA2002");

			if (e instanceof IncorrectResultSizeDataAccessException
					|| e instanceof EmptyResultDataAccessException)
				error.setDescription("Bad Request");
			else if (e instanceof DataAccessException)
				error.setDescription("Database error");
			else
				error.setDescription(e.getMessage());
			;

			saveData(error, null);
			saveResponse(null, metaData, error);

			List errors = new ArrayList();
			errors.add(error);
			responseEntity = new ResponseEntity<Response>(response,
					HttpStatus.NOT_FOUND);

		}
		return responseEntity;

}
	
	
	
	@ApiOperation(value = "inserts user record", notes = "Returns the status of insertion")
	@ApiParam(value = "single record to be inserted", required = true)
	@ApiResponses(value = {
			@ApiResponse(code = 405, message = "Method Not Supported", response = Response.class),
			@ApiResponse(code = 201, message = "Successful ", response = Response.class),
			@ApiResponse(code = 404, message = "Invalid Information Sent", response = Response.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = Response.class),
			@ApiResponse(code = 400, message = "Bad Request") })
	
	@RequestMapping(value="roles", method = RequestMethod.POST, consumes=MediaType.APPLICATION_JSON_VALUE, produces={MediaType.APPLICATION_JSON_VALUE})
	@ResponseStatus(value = HttpStatus.CREATED)
	public ResponseEntity<Response> insertRoles(@RequestBody RolesBean role) {
	

		ResponseEntity<Response> responseEntity = null;
		try {
			if(role.getRoleId()!=null&&role.getRoleName()!=null&&role.getRolePoints()!=0){
			
			
			
				RolesBean roleBean = rolesDAO.newRole(role);
				ArrayList<RolesBean> roleList = new ArrayList<RolesBean>();
				roleList.add(roleBean);

				if (roleBean!=null) {

					saveMetaData(true, "Record Created", "12348");
					saveData(null, roleList);
					saveResponse(data, metaData, null);

					responseEntity = new ResponseEntity<Response>(response,
							HttpStatus.OK);

				}

				else {

					ErrorDetails error = new ErrorDetails();
					error.setCode("TRA2013");
					error.setDescription("Unable to insert the record");
					List errors = new ArrayList();
					errors.add(error);

					saveData(error, null);
					saveMetaData(false, "Record Not Created", "14333");
					saveResponse(null, metaData, error);
					responseEntity = new ResponseEntity<Response>(response,
							HttpStatus.NOT_FOUND);

				

			}
			}
			else
			{
				ErrorDetails error = new ErrorDetails();
				error.setCode("TRA2014");
				error.setDescription("The required parameters missing");
				List errors = new ArrayList();
				errors.add(error);

				saveData(error, null);
				saveMetaData(false, "Record Not Created", "14333");
				saveResponse(null, metaData, error);
				responseEntity = new ResponseEntity<Response>(response,
						HttpStatus.NOT_FOUND);
			}
		}

		catch (Exception e) {

			ErrorDetails error = new ErrorDetails();
			error.setCode("TRA2014");

			if (e instanceof IncorrectResultSizeDataAccessException
					|| e instanceof EmptyResultDataAccessException)
				error.setDescription("Bad Request");
			else if (e instanceof DataAccessException)
				error.setDescription("Database error");
			else
				error.setDescription(e.getMessage());
			
			saveMetaData(false, "Error Occured", "respId12345");
			saveData(error, null);
			saveResponse(null, metaData, error);

			List errors = new ArrayList();
			errors.add(error);
			responseEntity = new ResponseEntity<Response>(response,
					HttpStatus.BAD_REQUEST);

		}
		return responseEntity;

	}

	
	
	@ApiOperation(value = "updates the users credits with PUT method", notes = "Returns the updated user record")
	@ApiParam(value = "object that need to be updated by using one id", required = true)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful Response", response = Response.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = Response.class),
			@ApiResponse(code = 400, message = "Bad Request", response = Response.class) })
	
	@RequestMapping(value="roles/{id}", method = RequestMethod.PUT, consumes=MediaType.APPLICATION_JSON_VALUE, produces={MediaType.APPLICATION_JSON_VALUE})
	@ResponseStatus(value = HttpStatus.CREATED)
	public ResponseEntity<Response> updateRoles(
			@ApiParam(value = "object that need to be deleted by using one id", required = true) @PathVariable("id") String id,@RequestBody RolesBean role) {

		List<RolesBean> list = new ArrayList<RolesBean>();

		ResponseEntity<Response> responseEntity = null;
		try {
			
				int n = rolesDAO.updateRole(id,role);
				if (n == 1) {
				
					List<RolesBean> roleList = rolesDAO.getRoleById(id);
					 
					
					String s = new String("Successfully Updated");
					saveMetaData(true, "Record Updated", "14359");
					saveData(null,roleList);
					saveResponse(data, metaData, null);

					responseEntity = new ResponseEntity<Response>(response,
							HttpStatus.OK);

				}

				else {
					ErrorDetails error = new ErrorDetails();
					error.setCode("TRA2009");
					error.setDescription("The user with the specified id is not found");
					List errors = new ArrayList();
					errors.add(error);
					saveMetaData(false, "Record not Updated", "12345");
					saveData(error, null);
					saveResponse(null, metaData, error);

					responseEntity = new ResponseEntity<Response>(response,
							HttpStatus.NOT_FOUND);

				}
			 
		} catch (Exception e) {
			saveMetaData(false, "Failed", "12345");

			ErrorDetails error = new ErrorDetails();
			error.setCode("TRA2011");

			if (e instanceof IncorrectResultSizeDataAccessException
					|| e instanceof EmptyResultDataAccessException)
				error.setDescription("Bad Request");
			else if (e instanceof DataAccessException)
				error.setDescription("Database error");
			else
				error.setDescription(e.getMessage());
			;
			saveMetaData(false, "Error Occured", "respId12345");
			saveData(error, null);
			saveResponse(null, metaData, error);

			List errors = new ArrayList();
			errors.add(error);
			responseEntity = new ResponseEntity<Response>(response,
					HttpStatus.NOT_FOUND);

		}

		return responseEntity;

	}
	
	
	@ApiOperation(value = "delete the template record with DELETE method", notes = "Returns the deleted template record")
	@ApiParam(value = "object that need to be deleted by using one id", required = true)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful Response", response = Response.class),
			@ApiResponse(code = 404, message = "Invalid Information Sent", response = Response.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = Response.class),
			@ApiResponse(code = 400, message = "Bad Request", response = Response.class),
			@ApiResponse(code = 405, message = "Method not Supported", response = Response.class)})
	
	@RequestMapping(value = "roles/{id}", method = RequestMethod.DELETE, produces = { MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<Response> removeAnnouncement(
			@ApiParam(value = "object that need to be deleted by using one id", required = true)@PathVariable("id") String id) {
	
		ResponseEntity<Response> responseEntity = null;
		try {
			
				List<RolesBean> annList = new ArrayList<RolesBean>();

				annList = rolesDAO.getRoleById(id);
				int n = rolesDAO.removeRole(id);

				if (n == 1) {
					//String s = new String("Deletion Successful");
					saveMetaData(true, "Record deleted", "14358");
					saveData(null, annList);
					saveResponse(data, metaData, null);
					responseEntity = new ResponseEntity<Response>(response,
							HttpStatus.OK);

				} else {
					ErrorDetails error = new ErrorDetails();
					error.setCode("TRA2006");
					error.setDescription("No such template");
					List errors = new ArrayList();
					errors.add(error);
					saveMetaData(false, "No such record", "12345");
					saveData(error, null);
					saveResponse(data, metaData, null);

					responseEntity = new ResponseEntity<Response>(response,
							HttpStatus.NOT_FOUND);

				
			} 
			} catch (Exception e) {
			saveMetaData(false, "Failed", "12347");

			ErrorDetails error = new ErrorDetails();
			error.setCode("TRA2008");

			if (e instanceof IncorrectResultSizeDataAccessException
					|| e instanceof EmptyResultDataAccessException)
				error.setDescription("Bad Request");
			else if (e instanceof DataAccessException)
				error.setDescription("Database error");
			else
				error.setDescription(e.getMessage());
			;
			saveMetaData(false, "Error Occured", "respId12345");
			saveData(error, null);
			saveResponse(null, metaData, error);

			List errors = new ArrayList();
			errors.add(error);
			responseEntity = new ResponseEntity<Response>(response,
					HttpStatus.NOT_FOUND);
			saveResponse(null, metaData, error);

		}
		return responseEntity;
				
			} 

	private void saveResponse(Data data, MetaData metaData,
			ErrorDetails errorDet) {
		response.setData(data);
		response.setMetaData(metaData);
		response.setError(errorDet);
	}

	private void saveData(ErrorDetails erroDet, List testObj) {
		response.setError(erroDet);
		data.setOutput(testObj);

	}

	private void saveMetaData(boolean success, String description,
			String responseId) {

		metaData.setSuccess(success);
		metaData.setDescription(description);
		metaData.setResponseId(responseId);
	}

}
