package com.hackathon.bean;

import io.swagger.annotations.ApiModelProperty;

public class VotingBean {
	
	 @ApiModelProperty(position =1 , required = true, value = "meeting number tracks the toastmasters weekly gathering")
private int meetingNo;
	 
	 @ApiModelProperty(position =2 , required = true, value = "role ID denotes the role available in every week toastmaster meeting")
private String roleId;
	 
	 @ApiModelProperty(position =3 , required = true, value = "employeed ID of voter containg only number")
private int voterEmpId;
	 
	 @ApiModelProperty(position =4 , required = true, value = "employeed ID of role player containg only number")
private int rolePlayerEmpId;
public int getMeetingNo() {
	return meetingNo;
}
public void setMeetingNo(int meetingNo) {
	this.meetingNo = meetingNo;
}
public String getRoleId() {
	return roleId;
}
public void setRoleId(String roleId) {
	this.roleId = roleId;
}
public int getVoterEmpId() {
	return voterEmpId;
}
public void setVoterEmpId(int voterEmpId) {
	this.voterEmpId = voterEmpId;
}
public int getRolePlayerEmpId() {
	return rolePlayerEmpId;
}
public void setRolePlayerEmpId(int rolePlayerEmpId) {
	this.rolePlayerEmpId = rolePlayerEmpId;
}
}
