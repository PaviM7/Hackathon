app.factory('meetingsFactory', ['$http', function($http) {

	
    var meetingsFactory = {};


	meetingsFactory.getMeetings = function () {
        return $http.get("../announcements");
    };

    meetingsFactory.getMeetingNo = function () {
        return $http.get("../meetingno");
    };
    
    return meetingsFactory;
}]);