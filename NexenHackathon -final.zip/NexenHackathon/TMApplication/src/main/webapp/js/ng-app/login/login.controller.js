app.controller('myCtrl',  ['$scope','$http','$cookieStore','$window','loginservice', function($scope, $http,$cookieStore,$window,loginservice) {
	$scope.setValue = function () {
	    
		$cookieStore.put("myValue", $scope.empid);
	    
	};

	$scope.getValue = function () {
	    $scope.value = $cookieStore.get('myValue');
	};

	$scope.getValue();
	$scope.setValue();
	
    $scope.sendGet = function() {
    	loginservice.authenticate($scope.pwd,$scope.empid);
$scope.message = "Please check the credentials";
    };
}]);

