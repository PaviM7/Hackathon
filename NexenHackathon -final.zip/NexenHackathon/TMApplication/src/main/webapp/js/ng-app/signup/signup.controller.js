
    
    
    
    app.controller('myCtrl', function ($scope, $http,$window,signupFactory){
      
        $scope.sendPost = function() {
        	
        	signupFactory.postToastmasters($scope.user) 
            .then(function (response) {
            	 $window.location.href = 'http://172.24.21.31:8080/TMApplication/views/LogIn.html';
            }, function (error) {
                $scope.status = 'Unable to load customer data: ' + error.message;
            });
     
        };
        
    });
