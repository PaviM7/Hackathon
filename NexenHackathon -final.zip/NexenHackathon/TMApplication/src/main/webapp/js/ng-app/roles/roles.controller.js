app.controller('viewrolesandpointsCtrl', ['$scope','$http' ,function ($scope,$http) {
	$http.get("../roles")
    .then(function (response) {$scope.roles = response.data.data.output;});
	
}]);
    