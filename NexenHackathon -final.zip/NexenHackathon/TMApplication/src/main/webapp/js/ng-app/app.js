var app = angular.module("myApp", ["ngRoute",'ngCookies']);
app.config(function($routeProvider) {
    $routeProvider
    .when("/Meetings", {
        templateUrl : "Meetings.html"
    })
    .when("/BookRoles", {
        templateUrl : "BookRoles.html"
    })
    .when("/Vote", {
        templateUrl : "../index.jsp"
    })
    .when("/ViewRolesAndPoints", {
        templateUrl : "viewrolesandpoints.html"
    })
    .when("/TermsAndConditions", {
        templateUrl : "TermsAndConditions.html"
    })
    .when("/LogOut", {
        templateUrl : "LogOut.html"
    });
});