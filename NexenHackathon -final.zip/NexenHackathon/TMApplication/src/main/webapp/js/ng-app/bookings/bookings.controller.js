app.controller('bookrolesCtrl', ['$scope','$http' , '$cookieStore', 'bookingsFactory',function ($scope,$http, $cookieStore,bookingsFactory) {
	
	
	
	$scope.meetingvalue = $cookieStore.get('currentMeeting');
	$scope.value = $cookieStore.get('myValue');
	var meetingval = $scope.meetingvalue;
	
	
	$scope.validateTheme = function()
		
		{
			var isEnable=false;
			
			if($scope.radioValue=="TMOD"&&$scope.theme!=null)
				return false;
			 if($scope.radioValue!="TMOD")
				return false;
			else return true;
		};
	  
		
	  $scope.insertBookings = function() {
		  
		  $scope.msg  = null;
		  console.log($scope.value+"testing");
		  
		  
		  var data = {
				  	"id": $scope.currentbookingid,
	                "employeeId": $scope.value,
	                "meetingNo": $scope.meetingvalue,
	                "roleId": $scope.radioValue,
	                "votes": 0
		  };
		  
		  bookingsFactory.postBookedRoles(data) 
            .then(function (response) {
            	if (response.data)
          		  $scope.msg = "Post Data Submitted Successfully!";
          		  alert($scope.msg);
          		  }, function (response) {
          			  
          		  $scope.msg = "Service not Exists";
          		  alert(msg);
          		  $scope.statusval = response.status;
          		  $scope.statustext = response.statusText;
          		  $scope.headers = response.headers();
          		  });
           
		
		  
		 
		  
		  var newtheme = {
				  
				  "theme" : $scope.theme
		  };
		  
		  alert("Theme is"+$scope.theme);
		  
		  if($scope.radioValue=="TMOD")
			  {
			  
			  bookingsFactory.putTheme(meetingval,newtheme) 
			  .then(function (response) {
				  alert("hello inside put");
			  if (response.data)
			  $scope.msg = "Put Data Submitted Successfully!";
			  alert($scope.msg);
			  }, function (response) {
				  
			  $scope.msg = "Service not Exists";
			  alert($scope.msg);
			  $scope.statusval = response.status;
			  $scope.statustext = response.statusText;
			  $scope.headers = response.headers();
			  });
		
		 
		  
			  }
		  $scope.showBookedDetails = true;
		  
		  };
		  

		  
		 
			  $http.get("../employeeids")
			    .then(function (response) {$scope.bookedids = response.data;
			    
			    var myEmpId = $scope.value;
			    var length = $scope.bookedids.length;
			    $cookieStore.put("disablemain", false);
			    	
			    for(var i = 0;i<length;i++)
				 {
				
			    	
				 if(angular.equals(myEmpId,$scope.bookedids[i]))
					 {
					 
					 $cookieStore.put("disablemain", true);
					 break;
					 }
					 
				 else
					 $cookieStore.put("disablemain", false);
				 }
			 
			 $scope.boo = $cookieStore.get('disablemain');
			 
			    });
			  
			 
			  
		$scope.setValue = function () {
	    $cookieStore.put("myValue", $scope.empid);

	};

	
	$scope.getValue = function () {
	    $scope.value = $cookieStore.get('myValue');
	};

	
	$scope.getValue();
	
	

	$http.get("../bookedroles")
	.then(function (response) {$scope.notavailableroles = response.data;});
	
    $http.get("../roles")
    .then(function (response) {$scope.roles = response.data.data.output;});
    
    $http.get("../pastroles/"+$scope.value)
    .then(function (response) {$scope.pastroles = response.data;});
    
    
    $http.get("../bookings")
    .then(function (response) {$scope.ids = response.data.data.output; var newid = $scope.ids.length+1;  $cookieStore.put("lastid", newid);  });
    
    $scope.currentbookingid = $cookieStore.get("lastid");
    
   
 //--------------------------------------------------------------------------------------------------------------------------------------------------  
    
    
    $scope.shouldBeDisabled = function (item,pastroles) {
    
    	var i = 0;
    	var j =1;
    	var k = 2;
    	
    	
    	
        if (item.roleId == pastroles[i] || item.roleId == pastroles[j] || item.roleId == pastroles[k]) {     
        	
        	return true;
        
        } else {     
        	
        	 return false;
        }
    };
    
    
    $scope.shouldBeDisabledtoo = function (item,notavailableroles) {
    	
    	
    	
        if (item.roleId == notavailableroles[0] || item.roleId == notavailableroles[1] ||
        item.roleId == notavailableroles[2] || item.roleId == notavailableroles[3] ||
        item.roleId == notavailableroles[4] || item.roleId == notavailableroles[5] ||
        item.roleId == notavailableroles[6] ||item.roleId == notavailableroles[7] ||
        item.roleId == notavailableroles[8] || item.roleId == notavailableroles[9] ||
        item.roleId == notavailableroles[10] || item.roleId == notavailableroles[11] ||
        item.roleId == notavailableroles[12] )
        
        {     
        return true;
        } else {     
        	
        	 return false;
        }
    };
    
 //-------------------------------------------------------------------------------------------------------------------------------------------------------------   
   
    
    $scope.selectedValue = function (myselection) {
    	var selected = "";
    	selected = myselection;
    	return selected;
    }
    
    
    $scope.chosenRole = function()
    {
    	$http.get("../bookings/"+$scope.value+"/"+$scope.meetingvalue)
	    .then(function (response) {$scope.rolename = response.data; $cookieStore.put("selectedrolename", $scope.rolename);});
	  
	 }
    
    $scope.chosenRole1 = function()
    {
    	$http.get("../bookings/"+$scope.value+"/"+$scope.meetingvalue)
	    .then(function (response) {$scope.rolename = response.data; $cookieStore.put("selectedrolename", $scope.rolename);});
    }
    
    $scope.chosenRole1();
    
    $scope.getMeRoleName = function(myselection)
    
    {
    	
    	
    	$scope.rolenamechosen = $cookieStore.get('selectedrolename');
    	
    	
    	if(angular.equals(myselection,"PS01"))
    		return "Prepared speaker 01";
    	
    	else if(angular.equals(myselection,"TTM"))
    		return "Table topic master";
    	
    	else if(angular.equals(myselection,"AC"))
    		return "Ah Counter";
    	
    	else if(angular.equals(myselection,"TMOD"))
    		return "Toastmaster of the day";
    	
    	else if(angular.equals(myselection,"PS02"))
    		return "Prepared Speaker 02";
    	
    	else if(angular.equals(myselection,"PS03"))
    		return "Prepared Speaker 03";
    	
    	else if(angular.equals(myselection,"TMR"))
    		return "Timer";
    	
    	else if(angular.equals(myselection,"GRAM"))
    		return "Grammarian";
    	
    	else if(angular.equals(myselection,"TTEVA"))
    		return "Table topic evaluator";
    	
    	else if(angular.equals(myselection,"PS01EVAL"))
    		return "Prepared speaker 01 evaluator";
    	
    	else if(angular.equals(myselection,"PS02EVAL"))
    		return "Prepared speaker 02 evaluator";
    	
    	else if(angular.equals(myselection,"PS03EVAL"))
    		return "Prepared speaker 03 evaluator";
    	
    	else 
    		return $scope.rolenamechosen;
    }
    
      
  
    
}]);
