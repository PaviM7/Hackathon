app.controller('logOutCtrl', ['$scope','$http' , '$cookieStore','$window','$location',function ($scope,$http, $cookieStore,$window,$location) {
	
	$scope.endMySession = function()
	{
		
		alert("say hi");
		$cookieStore.remove('myValue');
		$cookieStore.put("showme", true);
		$scope.sessionended = $cookieStore.get('showme');
		alert($scope.sessionended);
		$window.location.href = 'http://172.24.21.31:8080/TMApplication/views/LogIn.html';
		
	}
	
	$scope.checkMySession = function()
	{
		alert("say hello");
		return true;
	}
	
}]);
