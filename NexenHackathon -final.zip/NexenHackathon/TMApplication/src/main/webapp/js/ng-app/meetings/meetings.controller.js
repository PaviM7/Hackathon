app.controller('meetingsCtrl', ['$scope','$http' , '$cookieStore','$window','meetingsFactory',function ($scope,$http, $cookieStore,$window,meetingsFactory) {
	
	getMeetings();
	 
	function getMeetings() {
		meetingsFactory.getMeetings()
	            .then(function (response) {
	            	$scope.meetings = response.data.data.output;
	            }, function (error) {
	                $scope.status = 'Unable to load customer data: ' + error.message;
	            });
	}
	    
	getMeetingNo();
	
	function getMeetingNo() {
		meetingsFactory.getMeetingNo()
	            .then(function (response) {
	            	$scope.meetingno = response.data; $cookieStore.put("currentMeeting", $scope.meetingno);
	            }, function (error) {
	                $scope.status = 'Unable to load customer data: ' + error.message;
	            });
	}
    
   
    
	$scope.meeno = $cookieStore.get('currentMeeting');

	
}]);
