app.factory('bookingsFactory', ['$http', function($http) {
	var bookingsFactory = {};


	bookingsFactory.postBookedRoles = function (data) {
	return	$http.post('../bookings', JSON.stringify(data));
    };

    
    bookingsFactory.putTheme = function(meetingval,newtheme)
    {
    	return $http.put('../announcements/'+meetingval, JSON.stringify(newtheme));
    };
    
   
    
    return bookingsFactory;
         }]);