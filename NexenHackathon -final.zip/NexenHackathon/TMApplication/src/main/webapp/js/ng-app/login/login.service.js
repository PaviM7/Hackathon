app.service('loginservice', function($http,$window){
    this.authenticate = function(password,employeeId) {
    	var message;
    	
    	
    	 $http.get("../toastmasters").then(function (response) {
    	      
    	      var myData = response.data.data.output;
    	      for(var i=0; i < myData.length; i++) {
    	    	  
    	    	   
    	    	    if(myData[i].pwd==password&&myData[i].empid==employeeId)
    	    	    	
    	    	    	$window.location.href = "http://172.24.21.31:8080/TMApplication/views/HomePage.html";
    	    	    else
    	    	    	  message = "Please check the credentials";
    	    	}
    	    
    		
    	  }, function myError(response) {
    	       message = "Please check the credentials";

    	    
    	  });
    	
    	
    }
 });