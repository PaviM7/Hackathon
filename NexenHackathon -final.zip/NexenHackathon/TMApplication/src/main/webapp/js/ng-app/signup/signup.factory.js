app.factory('signupFactory', ['$http', function($http) {
	var signupFactory = {};


	signupFactory.postToastmasters = function (user) {
	return	$http({
	          method  : 'POST',
	          url     : '../toastmasters',
	          data    : user
	          
	         });
    };

    
    return signupFactory;
         }]);