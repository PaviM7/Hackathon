select * from T_XBBNHCJ_TOASTMASTERS

insert into T_XBBNHCJ_TOASTMASTERS values(12233,'xvvbbgc','Suji','Wolf',0)

create table T_XBBNHC9_Voting (MeetingNo int, RoleId varchar(5), VoterEmpId int, RolePlayerEmpId int)

insert into T_XBBNHC9_Voting values(1,'PS01',15902,15900)
insert into T_XBBNHC9_Voting values(1,'PS02',15912,15910)
insert into T_XBBNHC9_Voting values(2,'TT01',17902,13400)
select * from T_XBBNHC9_VOTING

update T_XBBNHC9_VOTING set voterEmpId=15903,roleplayerEmpId=15901  where roleId='PS01' and meetingNo=1

CREATE TABLE myTable (
       name  VARCHAR(25),
        
        start_date DATE);
        
        INSERT INTO myTable VALUES ('Pavi', '2004-07-12');
        
        INSERT INTO myTable VALUES ('Priya', '2004-07-11')


        
Alter table myTable add eventTime TIME

select * from myTable

Update MYTABLE set eventTime = '10:00:00' where name = 'Pavi'

MeetingNo    Date   Time  Venue


create table T_XBBNHC9_MeetingDetails(meetingNo int,meetingDate DATE,meetingTime TIME,meetingVenue varchar(30))

insert into T_XBBNHC9_MeetingDetails values (1,'2017-07-18','10:00:00','OAT','over','Environment')
update T_XBBNHC9_MEETINGDETAILS set meetingno = 5 where meetingvenue = 'OAT'

select * from T_XBBNHC9_MeetingDetails order by meetingdate desc 

select T_XBBNHCJ_ROLES.rolename from T_XBBNHCJ_ROLES  inner join  T_XBBNHCJ_BOOKINGS on T_XBBNHCJ_BOOKINGS.rolename = T_XBBNHCJ_ROLES.roleid where T_XBBNHCJ_BOOKINGS.meetingno = 7 and T_XBBNHCJ_BOOKINGS.employeeid = 34521

INSERT INTO T_XBBNHCJ_BOOKINGS VALUES (11,34521,7,'PS03',0);

update T_XBBNHCJ_BOOKINGS set  meetingNo = 7 where roleName ='Grammarian'

update T_XBBNHC9_MeetingDetails set meetingno=10 where  theme is null

delete from T_XBBNHC9_MEETINGDETAILS where meetingno=9 and theme is NULL



select * from T_XBBNHCJ_ROLES where roleid='AC'

select T_XBBNHCJ_ROLES.roleid, T_XBBNHCJ_TOASTMASTERS.employeename, T_XBBNHCJ_BOOKINGS.meetingno from T_XBBNHCJ_ROLES inner join  T_XBBNHCJ_BOOKINGS on T_XBBNHCJ_ROLES.rolename = T_XBBNHCJ_BOOKINGS.rolename
inner join T_XBBNHCJ_TOASTMASTERS on T_XBBNHCJ_BOOKINGS.employeeid = T_XBBNHCJ_TOASTMASTERS.employeeid order by T_XBBNHCJ_BOOKINGS.meetingno
 
update T_XBBNHCJ_BOOKINGS set  meetingno = 5 where id = 12

update T_XBBNHCJ_ROLES set  roleid = 'PS03EVAL'  where roleid = 'PS03EVA'

select * from T_XBBNHCJ_BOOKINGS

insert into T_XBBNHCJ_ROLES values ('TTS','TableTopicsSpeaker',10)

select * from T_XBBNHCJ_ROLES order by rolepoints desc


delete from T_XBBNHCJ_BOOKINGS where id=27

SELECT meetingno FROM T_XBBNHC9_MeetingDetails where status='forth coming'

create table T_XBBNHC9_ApplicableRoles (meetingno int, roleid id)

update T_XBBNHC9_MeetingDetails set theme=null where  meetingno =  9

delete from T_XBBNHCJ_BOOKINGS where id > 27

select employeeid from T_XBBNHCJ_BOOKINGS where meetingno = ?

SELECT meetingno FROM T_XBBNHC9_MeetingDetails order by meetingdate desc  FETCH FIRST ROW ONLY

SELECT id FROM T_XBBNHCJ_BOOKINGS order by id desc  FETCH FIRST ROW ONLY

SELECT meetingno FROM T_XBBNHC9_MeetingDetails where theme= 'Friends'

select rolename from T_XBBNHCJ_BOOKINGS where employeeid = 15902 and (meetingno = 5 or meetingno = 6 or meetingno = 7)
join
select rolename from T_XBBNHCJ_BOOKINGS where meetingno=?