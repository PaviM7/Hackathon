select * from T_XBBNHCJ_TOASTMASTERS

insert into T_XBBNHCJ_TOASTMASTERS values(12233,'xvvbbgc','Suji','Wolf',0)

create table T_XBBNHC9_Voting (MeetingNo int, RoleId varchar(5), VoterEmpId int, RolePlayerEmpId int)

insert into T_XBBNHC9_Voting values(1,'PS01',15902,15900)
insert into T_XBBNHC9_Voting values(1,'PS02',15912,15910)
insert into T_XBBNHC9_Voting values(2,'TT01',17902,13400)
select * from T_XBBNHC9_VOTING

update T_XBBNHC9_VOTING set voterEmpId=15903,roleplayerEmpId=15901  where roleId='PS01' and meetingNo=1

CREATE TABLE myTable (
       name  VARCHAR(25),
        
        start_date DATE);
        
        INSERT INTO myTable VALUES ('Pavi', '2004-07-12');
        
        INSERT INTO myTable VALUES ('Priya', '2004-07-11')


        
Alter table myTable add eventTime TIME

select * from myTable

Update MYTABLE set eventTime = '10:00:00' where name = 'Pavi'

MeetingNo    Date   Time  Venue


create table T_XBBNHC9_MeetingDetails(meetingNo int,meetingDate DATE,meetingTime TIME,meetingVenue varchar(30))

insert into T_XBBNHC9_MeetingDetails values (1,'2017-07-12','10:00:00','OAT')

select * from T_XBBNHC9_MeetingDetails

select * from T_XBBNHCJ_BOOKINGS
INSERT INTO T_XBBNHCJ_BOOKINGS VALUES (6,16574,12,'TT Master');
