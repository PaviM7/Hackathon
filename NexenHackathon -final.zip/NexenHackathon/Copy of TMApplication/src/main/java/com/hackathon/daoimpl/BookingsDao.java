package com.hackathon.daoimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;

import com.hackathon.bean.BookingsBean;
import com.hackathon.dao.IBookingsDAO;
import com.hackathon.rowmapper.BookingRowMapper;

@Component
public class BookingsDao extends JdbcDaoSupport implements IBookingsDAO {
	
	@Autowired
	public BookingsDao(DataSource dataSource) {
		// TODO Auto-generated constructor stub
		setDataSource(dataSource);
	}

	@Autowired
private Properties queryProps;
	
	public Properties getQueryProps() {
		return queryProps;
	}

	public void setQueryProps(Properties queryProps) {
		this.queryProps = queryProps;
	}

	public List<BookingsBean> getAllBookings() throws Exception {
		// TODO Auto-generated method stub
		String sql = queryProps.getProperty("getBookings");
		System.out.println(sql);
		List<BookingsBean> bookingList = new ArrayList<BookingsBean>();
		bookingList = getJdbcTemplate().query(sql,new Object[] {},new BookingRowMapper());
		return bookingList;
	}

	public BookingsBean bookRole(BookingsBean bookingsBean) throws Exception {
		// TODO Auto-generated method stub
		int numrows = 0;
		String SQL1 = queryProps.getProperty("setBooking");
		numrows = getJdbcTemplate().update(SQL1,new Object[]{bookingsBean.getId(),bookingsBean.getEmployeeId(),bookingsBean.getMeetingNo(),bookingsBean.getRoleId()});
		return( numrows == 1 ?  bookingsBean: null);
	}

	public int removeBooking(int id) throws Exception {
		// TODO Auto-generated method stub
		String SQL1 = queryProps.getProperty("deleteBooking");
		BookingsBean bookingBean = new BookingsBean();
		bookingBean.setId(id);

		int a = getJdbcTemplate().update(SQL1, new Object[]{bookingBean.getId()});
		
		return a;
	}

	public int updateBooking(int id, BookingsBean bookingBean) throws Exception {
		// TODO Auto-generated method stub
		String SQL1 = queryProps.getProperty("updatebooking");
		bookingBean.setId(id);
				int a=getJdbcTemplate().update(SQL1,new Object[]{bookingBean.getEmployeeId(),bookingBean.getMeetingNo(),bookingBean.getRoleId(),bookingBean.getId()});
				return a;
	}

	public List<BookingsBean> getBookingById(int bookingId) throws Exception {
		// TODO Auto-generated method stub
		String sql = queryProps.getProperty("getOneBooking");
		BookingsBean bookingBean = new BookingsBean();
		
		bookingBean.setId(bookingId);
		List<BookingsBean> bookingList = new ArrayList<BookingsBean>();
		bookingList = getJdbcTemplate().query(sql,new Object[] {bookingBean.getId()},new BookingRowMapper());
		return bookingList;
	}

}
