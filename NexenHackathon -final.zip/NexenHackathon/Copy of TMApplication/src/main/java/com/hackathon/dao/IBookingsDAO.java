package com.hackathon.dao;

import java.util.List;

import com.hackathon.bean.BookingsBean;

public interface IBookingsDAO {
	public List<BookingsBean> getAllBookings() throws Exception;
	public BookingsBean bookRole(BookingsBean bookingBean) throws Exception;
	public int removeBooking(int id) throws Exception;
	public int updateBooking(int id,BookingsBean bookingBean) throws Exception;
	public List<BookingsBean> getBookingById(int bookingId) throws Exception;

}
