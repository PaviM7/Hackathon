package com.hackathon.daoimpl;

import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;


import com.hackathon.bean.VotingBean;
import com.hackathon.dao.IVotingDAO;

import com.hackathon.rowmapper.VotingRowMapper;

public class VotingDao extends JdbcDaoSupport implements IVotingDAO{
	
	@Autowired
	public VotingDao(DataSource dataSource) {
		// TODO Auto-generated constructor stub
		setDataSource(dataSource);
	}

	@Autowired
	private Properties queryProps;
	
	public Properties getQueryProps() {
		return queryProps;
	}

	public void setQueryProps(Properties queryProps) {
		this.queryProps = queryProps;
	}


	public List<VotingBean> getAllVotes() throws Exception {
		// TODO Auto-generated method stub
		String sql = queryProps.getProperty("getVotes");
		List<VotingBean> vlist = new ArrayList<VotingBean>();
		vlist = getJdbcTemplate().query(sql,new Object[] {},new VotingRowMapper());
		return vlist;
		
	}

	
	public List<VotingBean> getVotingDetails(int meetingNo) throws Exception {
		
		String sql = queryProps.getProperty("getVotesByMeetingNo");
		List<VotingBean> vlist = new ArrayList<VotingBean>();
		
		vlist = getJdbcTemplate().query(sql,new Object[] { meetingNo }, new VotingRowMapper());	
		return vlist;
	}

	public VotingBean createVote(VotingBean VotingBeanObj) throws Exception {
		int numrows = 0;
		int[] types = { Types.INTEGER, Types.VARCHAR, Types.INTEGER,
				Types.INTEGER};
		Object param[] = { VotingBeanObj.getMeetingNo(), VotingBeanObj.getRoleId(),
				VotingBeanObj.getVoterEmpId(), VotingBeanObj.getRolePlayerEmpId()};
		
		String SQL1 = queryProps.getProperty("postVotes");
		numrows = getJdbcTemplate().update(SQL1, param, types);
		return( numrows == 1 ?  VotingBeanObj: null);
	}

	public VotingBean updateVotes(VotingBean VotingBeanObj,int meetingNo,String roleId) throws Exception {
		int numrows = 0;
		int[] types  = {Types.INTEGER,Types.INTEGER,Types.VARCHAR,Types.INTEGER};
		Object[] param ={VotingBeanObj.getVoterEmpId(),VotingBeanObj.getRolePlayerEmpId(),roleId,meetingNo};
		String SQL1 = queryProps.getProperty("putVotes");
		numrows = getJdbcTemplate().update(SQL1, param,types);
		return( numrows == 1 ?  VotingBeanObj: null);
	}

	public void deleteVotes(int MeetingNo) throws Exception {
String SQL1 = queryProps.getProperty("deleteVotes");
		
		getJdbcTemplate().update(SQL1, new Object[] { MeetingNo }, new int[] { Types.INTEGER });
		
	}

}
