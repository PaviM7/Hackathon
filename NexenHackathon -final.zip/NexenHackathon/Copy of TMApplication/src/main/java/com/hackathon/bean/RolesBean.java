package com.hackathon.bean;

import io.swagger.annotations.ApiModelProperty;

public class RolesBean {
	@ApiModelProperty(position =1 , required = true, value = "brief description of the property :roleId")

	private String roleId;
    @ApiModelProperty(position =2 , required = true, value = "brief description of the property :roleName")

	private String roleName;
    @ApiModelProperty(position =3 , required = true, value = "brief description of the property :rolePoints")

	private int rolePoints;
	public String getRoleId() {
		return roleId;
	}
	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	public int getRolePoints() {
		return rolePoints;
	}
	public void setRolePoints(int rolePoints) {
		this.rolePoints = rolePoints;
	}
}
