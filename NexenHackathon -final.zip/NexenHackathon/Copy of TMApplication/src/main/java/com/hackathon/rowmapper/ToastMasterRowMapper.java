package com.hackathon.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;


import org.springframework.jdbc.core.RowMapper;

import com.hackathon.bean.ToastMastersBean;

public class ToastMasterRowMapper implements RowMapper<ToastMastersBean> {

	

	public ToastMastersBean mapRow(ResultSet rs, int rowno) throws SQLException {
		// TODO Auto-generated method stub
		ToastMastersBean tm = new ToastMastersBean();
	      tm.setEmpid(rs.getInt(1));
	      tm.setCommitid(rs.getString(2));
	      tm.setName(rs.getString(3));
	      tm.setPwd(rs.getString(4));
	      
	      tm.setPoints(rs.getInt(5));
	   
		return tm;
	}

}
