package com.hackathon.daoimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;

import com.hackathon.bean.AnnouncementBean;
import com.hackathon.dao.IAnnouncementDAO;
import com.hackathon.rowmapper.AnnouncementRowMapper;

@Component
public class AnnouncementDao extends JdbcDaoSupport implements IAnnouncementDAO {

	
	@Autowired
	public AnnouncementDao(DataSource dataSource) {
		// TODO Auto-generated constructor stub
		setDataSource(dataSource);
	}

	@Autowired
private Properties queryProps;
	
	public Properties getQueryProps() {
		return queryProps;
	}

	public void setQueryProps(Properties queryProps) {
		this.queryProps = queryProps;
	}
	public List<AnnouncementBean> getAllMeetings() throws Exception {
		// TODO Auto-generated method stub
		String sql = queryProps.getProperty("getMeetings");
		System.out.println(sql);
		List<AnnouncementBean> AnnouncementList = new ArrayList<AnnouncementBean>();
		AnnouncementList = getJdbcTemplate().query(sql,new Object[] {},new AnnouncementRowMapper());
		return AnnouncementList;
	}

	public List<AnnouncementBean> getMeetingById(int id) throws Exception {
		// TODO Auto-generated method stub
		String sql = queryProps.getProperty("getOneMeeting");
		System.out.println(sql);
		AnnouncementBean AnnouncementBean  = new AnnouncementBean();		
		AnnouncementBean.setMeetingNo(id);

		List<AnnouncementBean> AnnouncementList = new ArrayList<AnnouncementBean>();
		AnnouncementList = getJdbcTemplate().query(sql,new Object[] {AnnouncementBean.getMeetingNo()},new AnnouncementRowMapper());
		return AnnouncementList;
	}

	public AnnouncementBean newMeeting(AnnouncementBean announcementBean) throws Exception {
		// TODO Auto-generated method stub
		int numrows = 0;
		String SQL1 = queryProps.getProperty("setMeeting");
		numrows = getJdbcTemplate().update(SQL1,new Object[]{announcementBean.getMeetingNo(),announcementBean.getMeetingDate(),announcementBean.getMeetingTime(),announcementBean.getMeetingVenue()});
		return( numrows == 1 ?  announcementBean: null);
	}

	public int removeMeeting(int id) throws Exception {
		// TODO Auto-generated method stub

		String SQL1 = queryProps.getProperty("deleteMeeting");
AnnouncementBean announcementBean  = new AnnouncementBean();		
announcementBean.setMeetingNo(id);

		int a = getJdbcTemplate().update(SQL1, new Object[]{announcementBean.getMeetingNo()});
		
		return a;
	}

	public int updateMeeting(int id, AnnouncementBean announcementBean) throws Exception {
		// TODO Auto-generated method stub
		String SQL1 = queryProps.getProperty("editMeeting");
		announcementBean.setMeetingNo(id);
				int a=getJdbcTemplate().update(SQL1,new Object[]{announcementBean.getMeetingDate(),announcementBean.getMeetingTime(),announcementBean.getMeetingVenue(),announcementBean.getMeetingNo()});
				return a;
	}

}
