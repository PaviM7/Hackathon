package com.hackathon.controller;


import com.hackathon.bean.*;
import com.hackathon.daoimpl.ToastMastersDAO;
import com.hackathon.model.Data;
import com.hackathon.model.ErrorDetails;
import com.hackathon.model.MetaData;
import com.hackathon.model.Response;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.*;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.TypeMismatchException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@EnableSwagger2
public class ToastMastersController {
	
	@Autowired
	ToastMastersDAO tmdao;
	
	
	@Autowired
	MetaData metaData;

	@Autowired
	Data data;
	@Autowired
	Response response;
	
	@Autowired
	ErrorDetails errorDetails;

	@RequestMapping(value="toastmasters",method = RequestMethod.GET, produces={MediaType.APPLICATION_JSON_VALUE})
	@ApiOperation(value = "retrieves the details of all toastmasters details created", notes = "More notes about this method", response = Response.class)  
	@ApiResponses(value = {
		    @ApiResponse(code = 200, message = "Successful retrieval of toastmasters details", response = Response.class),
		    @ApiResponse(code = 404, message = "User with given username does not exist",response = Response.class),		   
		    @ApiResponse(code = 400, message = "toastmaster with employee id does not exist",response = Response.class),
		    @ApiResponse(code = 500, message = "Internal Server Error",response = Response.class)}
		)
	public ResponseEntity<Response> viewToastMasters()
	{
		
		List<ToastMastersBean> tmlist = new ArrayList<ToastMastersBean>();
		try {
			tmlist = tmdao.getAllToastMasters();
			saveMetaData(true,"Toastmasters details loaded","12345");
			saveData(null, tmlist);
			saveResponse(data,metaData, null);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			errorDetails.setCode("00005");
			errorDetails.setDescription(e.getMessage());;
			saveMetaData(false,"Error Occured","12345");
			
			saveResponse(null,metaData,errorDetails);
			return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST) ;
			
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
	
	
	@ApiOperation(value = "insert new toastmaster details", notes = "More notes about this method", response = Response.class)  
	@ApiResponses(value = {
		  //@ApiResponse(code = 200, message = "OK", response = Response.class),
			@ApiResponse(code = 201, message = "Successful retrieval of details", response = Response.class),
		    @ApiResponse(code = 404, message = "Check Invocation URL",response = Response.class),		   
		    @ApiResponse(code = 400, message = "Incorrect details in request body",response = Response.class),
		    @ApiResponse(code = 500, message = "Internal Server Error",response = Response.class)}
		)
	@RequestMapping(value="toastmasters", method = RequestMethod.POST, consumes=MediaType.APPLICATION_JSON_VALUE, produces={MediaType.APPLICATION_JSON_VALUE})
	@ResponseStatus(value = HttpStatus.CREATED)
	public ResponseEntity<Response> insertToastMasters(@RequestBody ToastMastersBean tmbean)
	{
		List<ToastMastersBean> tmlist = new ArrayList<ToastMastersBean>();
		tmlist = tmdao.getAllToastMasters();
		try {
			tmbean = tmdao.createToastMaster(tmbean);
				
			tmlist.add(tmbean);	
			saveMetaData(true,"Inserted","200");
			saveData(null, tmlist);
			saveResponse(data,metaData, null);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			errorDetails.setCode("11111");
			errorDetails.setDescription(e.getMessage());
			saveMetaData(false,"Error Occured","400");
			
			saveResponse(null,metaData,errorDetails);
			return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST) ;
		}
		
		
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
	
	
	
	@ApiOperation(value = "update the credentials", notes = "More notes about this method", response = Response.class)  
	@ApiResponses(value = {
		@ApiResponse(code = 200, message = "Success", response = Response.class),
		@ApiResponse(code = 201, message = "Created", response = Response.class),
		@ApiResponse(code = 404, message = "Toastmaster with given empid does not exist",response = Response.class),		   
		@ApiResponse(code = 400, message = "No such item exist",response = Response.class),
		@ApiResponse(code = 500, message = "Internal Server Error",response = Response.class)}
		)
	@RequestMapping(value="toastmasters/{employeeid}",method = RequestMethod.PUT, consumes=MediaType.APPLICATION_JSON_VALUE, produces={MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<Response> updateToastMasters(@RequestBody ToastMastersBean tmbean , @ApiParam(name = "employeeid", value = "please enter the employee id ranging between 10000 to 99999 ", required = true) @PathVariable int employeeid)
	{
		List<ToastMastersBean> tmlist = new ArrayList<ToastMastersBean>();
		
		
		
		try {
			tmdao.updateToastMaster(tmbean);
			saveMetaData(true,"Updated","10025");
			saveData(null, tmlist);
			saveResponse(data,metaData, null);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			errorDetails.setCode("00005");
			errorDetails.setDescription(e.getMessage());
			saveMetaData(false,"Error Occured","400");
			
			saveResponse(null,metaData,errorDetails);
			return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST) ;
				
		}
		tmlist = tmdao.getAllToastMasters();
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
	
	@RequestMapping(value="toastmasters/{employeeid}",method = RequestMethod.DELETE, consumes=MediaType.APPLICATION_JSON_VALUE, produces={MediaType.APPLICATION_JSON_VALUE})
	@ApiOperation(value = "delete a toastmaster once he is no more a club member", notes = "More notes about this method", response = Response.class)
	@ApiResponses(value = {
		    @ApiResponse(code = 200, message = "Successful deletion  of toastmaster details ", response = Response.class),
		    @ApiResponse(code = 404, message = "Employee with given empid does not exist",response = Response.class),
		    @ApiResponse(code = 400, message = "No such item exist",response = Response.class),
		    @ApiResponse(code = 500, message = "Internal Server Error",response = Response.class)}
		)
	public Response  deleteToastMasters(@ApiParam(name = "employeeid", value = "employee id ranging between 10000 to 99999", required = true) @PathVariable int employeeid)
	{
		List<ToastMastersBean> tmlist = new ArrayList<ToastMastersBean>();
		
		try {
			tmdao.deleteToastMaster(employeeid);
			saveMetaData(true,"Deleted","24541");
			saveData(null, tmlist);
			saveResponse(data,metaData, null);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			errorDetails.setDescription("Bad SQL grammar");
			
			errorDetails.setCode("ORA-00942");
			saveMetaData(false,"Error Occured","24541");
			//saveData(errorDetails, null);
			saveResponse(null,metaData,errorDetails);	
		
		}
		tmlist = tmdao.getAllToastMasters();
		return response;
	}
	
@RequestMapping(value="toastmasters/{id}", method=RequestMethod.GET, produces={ MediaType.APPLICATION_JSON_VALUE})
@ApiOperation(value = "Get the details of toastmaster created", notes = "More notes about this method", response = Response.class)
@ApiResponses(value = {
	    @ApiResponse(code = 200, message = "Successful retrieval of toastmasters details", response = Response.class),
	    @ApiResponse(code = 404, message = "User with given username does not exist",response = Response.class),
	    @ApiResponse(code = 400, message = "toastmaster with employee id does not exist",response = Response.class),
	    @ApiResponse(code = 500, message = "Internal Server Error",response = Response.class)}
	)
	public ResponseEntity<Response>  getMemberDetails(@ApiParam(name = "id", value = "Numeric login to the application", required = true) @PathVariable("id") int employeeid)
	{
		
	List<ToastMastersBean> tmlist = new ArrayList<ToastMastersBean>();
		try {
			tmlist =	tmdao.getToastMasterDetails(employeeid);

			saveMetaData(true,"Tests loaded","12345");
			saveData(null, tmlist);
			saveResponse(data,metaData, null);
			return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST) ;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			errorDetails.setCode("00005");
			
			if( e instanceof IncorrectResultSizeDataAccessException  || e instanceof EmptyResultDataAccessException)
				errorDetails.setDescription("Bad Request");
			else if( e instanceof DataAccessException)
				errorDetails.setDescription("Database error");
			else
				errorDetails.setDescription(e.getMessage());;
			saveMetaData(false,"Error Occured","respId12345");
			
			saveResponse(null,metaData, errorDetails);
			
		}
		
				
			
		return  new ResponseEntity<Response>(response, HttpStatus.OK) ;
	}

private void saveMetaData(boolean success, String description, String responseId){
	
	
	metaData.setSuccess(success);
	metaData.setDescription(description);
	metaData.setResponseId(responseId);
}

private void saveResponse(Data data, MetaData metaData, ErrorDetails errorDet) {
	response.setData(data);
	response.setMetaData(metaData);
	response.setError(errorDet);
}
private void saveData(ErrorDetails erroDet, List testObj) {
	response.setError(erroDet);
		data.setOutput(testObj);
	
}

@ExceptionHandler(TypeMismatchException.class)

public @ResponseBody ResponseEntity<Object> typeMismatchExceptionHandler(TypeMismatchException exception, HttpServletRequest request) {

    metaData.setDescription(null);

	metaData.setSuccess(false);

	response.setData(null);

    errorDetails.setCode("400");

	errorDetails.setDescription("Type mismatch exception occured");

    response.setError(errorDetails);

    ResponseEntity<Object> responseEntity = new ResponseEntity<Object>(

    		   response, HttpStatus.BAD_REQUEST);

       return responseEntity;

}

@ExceptionHandler(Exception.class)

public @ResponseBody ResponseEntity<Object> generalExceptionHandler(

              Exception exception, HttpServletRequest request) {

      

	errorDetails.setCode("400");

	errorDetails.setDescription("Bad Request");

       ResponseEntity<Object> responseEntity = new ResponseEntity<Object>(

    		   response, HttpStatus.BAD_REQUEST);

       return responseEntity;

}
	
}
