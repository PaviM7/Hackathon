package com.hackathon.dao;

import java.util.List;

import com.hackathon.bean.AnnouncementBean;

public interface IAnnouncementDAO {
	
	public List<AnnouncementBean> getAllMeetings() throws Exception;
	public List<AnnouncementBean> getMeetingById(int id) throws Exception;

	public AnnouncementBean newMeeting(AnnouncementBean AnnouncementBean) throws Exception;
	public int removeMeeting(int id) throws Exception;
	public int updateMeeting(int id,AnnouncementBean AnnouncementBean) throws Exception;

}
