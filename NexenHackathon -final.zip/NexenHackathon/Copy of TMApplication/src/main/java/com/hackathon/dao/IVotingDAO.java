package com.hackathon.dao;

import java.util.List;

import com.hackathon.bean.VotingBean;

public interface IVotingDAO {
	public List<VotingBean> getAllVotes() throws Exception;
	public List<VotingBean> getVotingDetails(int meetingNo) throws Exception;
	public VotingBean createVote(VotingBean VotingBeanObj) throws Exception;
	public VotingBean updateVotes(VotingBean VotingBeanObj,int meetingNo,String roleId) throws Exception;
	public void deleteVotes(int MeetingNo) throws Exception;
}
