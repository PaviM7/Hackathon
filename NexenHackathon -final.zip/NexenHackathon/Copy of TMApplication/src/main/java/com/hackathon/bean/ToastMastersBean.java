package com.hackathon.bean;

import io.swagger.annotations.ApiModelProperty;

public class ToastMastersBean {

@ApiModelProperty(position = 1, required = true, value = "Employeed ID containg only number")	
private int empid;
@ApiModelProperty(position = 2, required = true, value = "Commit ID of individuals containing alphanumerals")
private String commitid;
@ApiModelProperty(position = 3, required = true, value = "Name of the toastmaster")
private String name;
@ApiModelProperty(position = 4, required = true, value = "Password that is set by the user while signing up")
private String pwd;
@ApiModelProperty(position = 5, required = true, value = "Points of individual toastmasters")
private int points;

public int getEmpid() {
	return empid;
}
public void setEmpid(int empid) {
	this.empid = empid;
}
public String getCommitid() {
	return commitid;
}
public void setCommitid(String commitid) {
	this.commitid = commitid;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getPwd() {
	return pwd;
}
public void setPwd(String pwd) {
	this.pwd = pwd;
}
public int getPoints() {
	return points;
}
public void setPoints(int points) {
	this.points = points;
}
	
}
