package com.hackathon.daoimpl;

import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;

import com.hackathon.bean.ToastMastersBean;
import com.hackathon.bean.VotingBean;
import com.hackathon.dao.IToastMastersDAO;
import com.hackathon.rowmapper.ToastMasterRowMapper;
import com.hackathon.rowmapper.VotingRowMapper;

@Component
public class ToastMastersDAO extends JdbcDaoSupport implements IToastMastersDAO{
	
	@Autowired
	public ToastMastersDAO(DataSource dataSource) {
		// TODO Auto-generated constructor stub
		setDataSource(dataSource);
	}

	@Autowired
	private Properties queryProps;
	

	public List<ToastMastersBean> getAllToastMasters()  {
		
		// TODO Auto-generated method stub
		String sql = queryProps.getProperty("getToastMasters");
		List<ToastMastersBean> tmlist = new ArrayList<ToastMastersBean>();
		tmlist = getJdbcTemplate().query(sql,new Object[] {},new ToastMasterRowMapper());
		return tmlist;
	}

	public Properties getQueryProps() {
		return queryProps;
	}

	public void setQueryProps(Properties queryProps) {
		this.queryProps = queryProps;
	}

	

	public ToastMastersBean createToastMaster(ToastMastersBean ToastMastersBeanObj) throws Exception {
		// TODO Auto-generated method stub\
		int numrows = 0;
		int[] types = { Types.INTEGER, Types.VARCHAR, Types.VARCHAR,
				Types.VARCHAR, Types.INTEGER };
		Object param[] = { ToastMastersBeanObj.getEmpid(), ToastMastersBeanObj.getCommitid(),
				ToastMastersBeanObj.getName(), ToastMastersBeanObj.getPwd(), 
				ToastMastersBeanObj.getPoints() };
		
		String SQL1 = queryProps.getProperty("postToastMasters");
		numrows = getJdbcTemplate().update(SQL1, param, types);
		return( numrows == 1 ?  ToastMastersBeanObj: null);
	}

	public ToastMastersBean updateToastMaster(ToastMastersBean ToastMastersBeanObj) throws Exception {
		// TODO Auto-generated method stub
		int numrows = 0;
		int[] types  = {Types.VARCHAR,Types.INTEGER};
		Object[] param ={ToastMastersBeanObj.getPwd(),ToastMastersBeanObj.getEmpid()};
		String SQL1 = queryProps.getProperty("putToastMasters");
		numrows = getJdbcTemplate().update(SQL1, param,types);
		return( numrows == 1 ?  ToastMastersBeanObj: null);
		
	}

	public void deleteToastMaster(int empid) throws Exception {
		
		
		String SQL1 = queryProps.getProperty("deleteToastMasters");
		
		getJdbcTemplate().update(SQL1, new Object[] { empid }, new int[] { Types.INTEGER });
		
	}

	public List<ToastMastersBean> getToastMasterDetails(int empid) throws Exception {
		
		List<ToastMastersBean> tmlist = new ArrayList<ToastMastersBean>();
		String sql = queryProps.getProperty("getToastMastersByEmpId");
		
		
		tmlist =  getJdbcTemplate().query(sql,new Object[] { empid }, new ToastMasterRowMapper());	
		
		return tmlist;
	}




	
	
}
