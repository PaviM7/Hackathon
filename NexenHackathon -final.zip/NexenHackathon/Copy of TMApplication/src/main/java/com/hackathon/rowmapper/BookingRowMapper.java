package com.hackathon.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.hackathon.bean.AnnouncementBean;
import com.hackathon.bean.BookingsBean;

public class BookingRowMapper implements RowMapper<BookingsBean> {

	public BookingsBean mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
BookingsBean bookingObj = new BookingsBean();
		
		bookingObj.setId(rs.getInt(1));
		bookingObj.setEmployeeId(rs.getInt(2));
		bookingObj.setMeetingNo(rs.getInt(3));
		bookingObj.setRoleId(rs.getString(4));
	     return bookingObj;
	}

}
