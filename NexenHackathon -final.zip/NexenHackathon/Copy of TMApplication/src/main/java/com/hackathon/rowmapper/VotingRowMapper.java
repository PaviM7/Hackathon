package com.hackathon.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;


import com.hackathon.bean.VotingBean;

public class VotingRowMapper implements RowMapper<VotingBean> {

	public VotingBean mapRow(ResultSet rs, int rowNum) throws SQLException {
		  VotingBean vb = new VotingBean();
	      vb.setMeetingNo(rs.getInt(1));
	      vb.setRoleId(rs.getString(2));
	      vb.setVoterEmpId(rs.getInt(3));
	     
	      
	      vb.setRolePlayerEmpId(rs.getInt(4));
	   
		return vb;
	}

}
