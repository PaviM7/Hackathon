package com.hackathon.bean;

import io.swagger.annotations.ApiModelProperty;

public class VotingBean {
	
@ApiModelProperty(position = 1, required = true, value = "Meeting number tracks the toastmasters weekly gathering")	
private int MeetingNo;
@ApiModelProperty(position = 2, required = true, value = "Role ID denotes the role available in every week toastmaster meeting")
private String RoleId;
@ApiModelProperty(position = 3, required = true, value = "Employeed ID of voter containg only number")
private int VoterEmpId;
@ApiModelProperty(position = 4, required = true, value = "Employeed ID of role player containg only number")
private int RolePlayerEmpId;
public int getMeetingNo() {
	return MeetingNo;
}
public void setMeetingNo(int meetingNo) {
	MeetingNo = meetingNo;
}
public String getRoleId() {
	return RoleId;
}
public void setRoleId(String roleId) {
	RoleId = roleId;
}
public int getVoterEmpId() {
	return VoterEmpId;
}
public void setVoterEmpId(int voterEmpId) {
	VoterEmpId = voterEmpId;
}
public int getRolePlayerEmpId() {
	return RolePlayerEmpId;
}
public void setRolePlayerEmpId(int rolePlayerEmpId) {
	RolePlayerEmpId = rolePlayerEmpId;
}
}
