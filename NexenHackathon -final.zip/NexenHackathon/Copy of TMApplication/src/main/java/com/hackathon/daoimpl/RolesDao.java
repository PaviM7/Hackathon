package com.hackathon.daoimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;

import com.hackathon.bean.RolesBean;
import com.hackathon.dao.IRolesDAO;
import com.hackathon.rowmapper.RolesRowMapper;
@Component
public class RolesDao extends JdbcDaoSupport implements IRolesDAO {

	
	@Autowired
	public RolesDao(DataSource dataSource) {
		// TODO Auto-generated constructor stub
		setDataSource(dataSource);
	}

	@Autowired
private Properties queryProps;
	
	public Properties getQueryProps() {
		return queryProps;
	}

	public void setQueryProps(Properties queryProps) {
		this.queryProps = queryProps;
	}

	public List<RolesBean> getAllRoles() throws Exception {
		String sql = queryProps.getProperty("getRoles");
		System.out.println(sql);
		List<RolesBean> rolesList = new ArrayList<RolesBean>();
		rolesList = getJdbcTemplate().query(sql,new Object[] {},new RolesRowMapper());
		return rolesList;
	}

	public List<RolesBean> getRoleById(String id) throws Exception {
		// TODO Auto-generated method stub
		String sql = queryProps.getProperty("getOneRole");
		System.out.println(sql);
		RolesBean rolesBean  = new RolesBean();		
		rolesBean.setRoleId(id);

		List<RolesBean> rolesList = new ArrayList<RolesBean>();
		rolesList = getJdbcTemplate().query(sql,new Object[] {rolesBean.getRoleId()},new RolesRowMapper());
		return rolesList;
	}

	public RolesBean newRole(RolesBean rolesBean) throws Exception {
		// TODO Auto-generated method stub
		int numrows = 0;
		String SQL1 = queryProps.getProperty("setRole");
		numrows = getJdbcTemplate().update(SQL1,new Object[]{rolesBean.getRoleId(),rolesBean.getRoleName(),rolesBean.getRolePoints()});
		return( numrows == 1 ?  rolesBean: null);
	}

	public int removeRole(String id) throws Exception {
		// TODO Auto-generated method stub
		String SQL1 = queryProps.getProperty("deleteRole");
		RolesBean rolesBean  = new RolesBean();		
				rolesBean.setRoleId(id);

				int a = getJdbcTemplate().update(SQL1, new Object[]{rolesBean.getRoleId()});
				
				return a;
	}

	public int updateRole(String id, RolesBean rolesBean) throws Exception {
		// TODO Auto-generated method stub
		String SQL1 = queryProps.getProperty("editRole");
		rolesBean.setRoleId(id);
				int a=getJdbcTemplate().update(SQL1,new Object[]{rolesBean.getRoleName(),rolesBean.getRolePoints(),rolesBean.getRoleId()});
				return a;
	}

}
