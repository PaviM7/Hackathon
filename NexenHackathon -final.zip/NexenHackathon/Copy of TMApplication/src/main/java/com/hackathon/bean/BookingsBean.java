package com.hackathon.bean;

import io.swagger.annotations.ApiModelProperty;

public class BookingsBean {
	 @ApiModelProperty(position =1 , required = true, value = "brief description of the property :id")

		private int id;
	    @ApiModelProperty(position = 2, required = true, value = "brief description of the property :employeeId")


	    private int employeeId;
	    @ApiModelProperty(position =3 , required = true, value = "brief description of the property :meetingNo")

	    private int meetingNo;
	    @ApiModelProperty(position = 4, required = true, value = "brief description of the property :roleId")

		private String roleId;
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public int getEmployeeId() {
			return employeeId;
		}
		public void setEmployeeId(int employeeId) {
			this.employeeId = employeeId;
		}
		public int getMeetingNo() {
			return meetingNo;
		}
		public void setMeetingNo(int meetingNo) {
			this.meetingNo = meetingNo;
		}
		public String getRoleId() {
			return roleId;
		}
		public void setRoleId(String roleId) {
			this.roleId = roleId;
		}
}
