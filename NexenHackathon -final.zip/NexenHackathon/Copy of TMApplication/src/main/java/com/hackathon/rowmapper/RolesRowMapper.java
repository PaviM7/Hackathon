package com.hackathon.rowmapper;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.hackathon.bean.*;
public class RolesRowMapper implements RowMapper<RolesBean>{

	public RolesBean mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
RolesBean rolesObj = new RolesBean();
		
		rolesObj.setRoleId(rs.getString(1));
		rolesObj.setRoleName(rs.getString(2));
		rolesObj.setRolePoints(rs.getInt(3));
	     return rolesObj;
	}

}
