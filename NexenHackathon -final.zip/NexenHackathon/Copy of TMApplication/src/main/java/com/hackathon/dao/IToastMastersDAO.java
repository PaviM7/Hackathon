package com.hackathon.dao;

import java.util.List;

import com.hackathon.bean.ToastMastersBean;

public interface IToastMastersDAO {
	public List<ToastMastersBean> getAllToastMasters() throws Exception;
	public List<ToastMastersBean> getToastMasterDetails(int empid) throws Exception;
	public ToastMastersBean createToastMaster(ToastMastersBean ToastMastersBeanObj) throws Exception;
	public ToastMastersBean updateToastMaster(ToastMastersBean ToastMastersBeanObj) throws Exception;
	public void deleteToastMaster(int empid) throws Exception;
}
