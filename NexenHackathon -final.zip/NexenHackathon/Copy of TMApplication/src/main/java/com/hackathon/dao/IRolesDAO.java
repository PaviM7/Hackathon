package com.hackathon.dao;

import java.util.List;

import com.hackathon.bean.RolesBean;

public interface IRolesDAO {
	public List<RolesBean> getAllRoles() throws Exception;
	public List<RolesBean> getRoleById(String id) throws Exception;

	public RolesBean newRole(RolesBean rolesBean) throws Exception;
	public int removeRole(String id) throws Exception;
	public int updateRole(String id,RolesBean rolesBean) throws Exception;
}
