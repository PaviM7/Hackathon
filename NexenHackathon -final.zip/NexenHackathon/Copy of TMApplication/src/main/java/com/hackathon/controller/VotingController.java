package com.hackathon.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.TypeMismatchException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;


import com.hackathon.bean.VotingBean;

import com.hackathon.daoimpl.VotingDao;
import com.hackathon.model.Data;
import com.hackathon.model.ErrorDetails;
import com.hackathon.model.MetaData;
import com.hackathon.model.Response;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@RestController
@EnableSwagger2
public class VotingController {
	@Autowired
	VotingDao vdao;
	@Autowired
	MetaData metaData;

	@Autowired
	Data data;
	@Autowired
	Response response;
	
	@Autowired
	ErrorDetails errorDetails;

	@RequestMapping(value="votes",method = RequestMethod.GET, produces={MediaType.APPLICATION_JSON_VALUE})
	@ApiOperation(value = "retrieves the details of all toastmasters details created", notes = "More notes about this method", response = Response.class)  
	@ApiResponses(value = {
		    @ApiResponse(code = 200, message = "Successful retrieval of voting details", response = Response.class),
		    @ApiResponse(code = 404, message = "User with given username does not exist",response = Response.class),		   
		    @ApiResponse(code = 400, message = "toastmaster with employee id does not exist",response = Response.class),
		    @ApiResponse(code = 500, message = "Internal Server Error",response = Response.class)}
		)
	public ResponseEntity<Response> viewVotes()
	{
		
		List<VotingBean> vlist = new ArrayList<VotingBean>();
		try {
			vlist = vdao.getAllVotes();
			saveMetaData(true,"Toastmasters details loaded","12345");
			saveData(null, vlist);
			saveResponse(data,metaData, null);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
	
			errorDetails.setCode("00005");
			errorDetails.setDescription(e.getMessage());;
			saveMetaData(false,"Error Occured","12345");
			
			saveResponse(null,metaData,errorDetails);
			return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST) ;
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
	
	
	
	@ApiOperation(value = "caste new vote", notes = "More notes about this method", response = Response.class)  
	@ApiResponses(value = {
		  //@ApiResponse(code = 200, message = "OK", response = Response.class),
			@ApiResponse(code = 201, message = "Successful retrieval of details", response = Response.class),
		    @ApiResponse(code = 404, message = "Check Invocation URL",response = Response.class),		   
		    @ApiResponse(code = 400, message = "Incorrect details in request body",response = Response.class),
		    @ApiResponse(code = 500, message = "Internal Server Error",response = Response.class)}
		)
	@RequestMapping(value="votes", method = RequestMethod.POST, consumes=MediaType.APPLICATION_JSON_VALUE, produces={MediaType.APPLICATION_JSON_VALUE})
	@ResponseStatus(value = HttpStatus.CREATED)
	public ResponseEntity<Response> insertToastMasters(@RequestBody VotingBean vbean)
	{
		List<VotingBean> vlist = new ArrayList<VotingBean>();
		
		try {
			vlist = vdao.getAllVotes();
			vbean = vdao.createVote(vbean);
				
			vlist.add(vbean);	
			saveMetaData(true,"Inserted","200");
			saveData(null, vlist);
			saveResponse(data,metaData, null);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			errorDetails.setCode("11111");
			errorDetails.setDescription(e.getMessage());
			saveMetaData(false,"Error Occured","400");
			
			saveResponse(null,metaData,errorDetails);
			return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST) ;
		}
		
		
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
	
	
	@ApiOperation(value = "update the votes", notes = "More notes about this method", response = Response.class)  
	@ApiResponses(value = {
		@ApiResponse(code = 200, message = "Success", response = Response.class),
		@ApiResponse(code = 201, message = "Created", response = Response.class),
		@ApiResponse(code = 404, message = "Toastmaster with given empid does not exist",response = Response.class),		   
		@ApiResponse(code = 400, message = "No such item exist",response = Response.class),
		@ApiResponse(code = 500, message = "Internal Server Error",response = Response.class)}
		)
	@RequestMapping(value="votes/{meetingNo}/{roleid}",method = RequestMethod.PUT, consumes=MediaType.APPLICATION_JSON_VALUE, produces={MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<Response> updateToastMasters(@RequestBody VotingBean vbean ,@ApiParam(name = "meetingNo", value = "please enter the meeting number ", required = true) @PathVariable int meetingNo,@ApiParam(name = "roleid", value = "please enter the role ID ", required = true) @PathVariable String roleid)
	{
		List<VotingBean> vlist = new ArrayList<VotingBean>();
		
		
		
		try {
			vdao.updateVotes(vbean,meetingNo,roleid);
			vlist = vdao.getAllVotes();
			saveMetaData(true,"Updated","10025");
			saveData(null, vlist);
			saveResponse(data,metaData, null);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			errorDetails.setCode("00005");
			errorDetails.setDescription(e.getMessage());
			saveMetaData(false,"Error Occured","400");
			
			saveResponse(null,metaData,errorDetails);
			return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST) ;
		}
		
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
	
	
	@ApiOperation(value = "delete votes if it is not a valid one", notes = "More notes about this method", response = Response.class)
	@ApiResponses(value = {
		    @ApiResponse(code = 200, message = "Successful deletion  of voting details ", response = Response.class),
		    @ApiResponse(code = 404, message = "Employee with given empid does not exist",response = Response.class),
		    @ApiResponse(code = 400, message = "No such item exist",response = Response.class),
		    @ApiResponse(code = 500, message = "Internal Server Error",response = Response.class)}
		)
	@RequestMapping(value="votes/{meetingNo}",method = RequestMethod.DELETE, consumes=MediaType.APPLICATION_JSON_VALUE, produces={MediaType.APPLICATION_JSON_VALUE})
	public Response deleteToastMasters(@ApiParam(name = "meetingNo", value = "enter a valid meeting number", required = true) @PathVariable int meetingNo)
	{
		List<VotingBean> vlist = new ArrayList<VotingBean>();
		
		try {
			vdao.deleteVotes(meetingNo);
			vlist = vdao.getAllVotes();
			saveMetaData(true,"Deleted","24541");
			saveData(null, vlist);
			saveResponse(data,metaData, null);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
            errorDetails.setDescription("Bad SQL grammar");
			
			errorDetails.setCode("ORA-00942");
			saveMetaData(false,"Error Occured","24541");
			//saveData(errorDetails, null);
			saveResponse(null,metaData,errorDetails);	
		}
		
		return response;
	}
	

	@RequestMapping(value="votes/{id}", method=RequestMethod.GET, produces={ MediaType.APPLICATION_JSON_VALUE})
	@ApiOperation(value = "Get the details of particular vote", notes = "More notes about this method", response = Response.class)
	@ApiResponses(value = {
		    @ApiResponse(code = 200, message = "Successful retrieval of voting details", response = Response.class),
		    @ApiResponse(code = 404, message = "User with given username does not exist",response = Response.class),
		    @ApiResponse(code = 400, message = "toastmaster with employee id does not exist",response = Response.class),
		    @ApiResponse(code = 500, message = "Internal Server Error",response = Response.class)}
		)
	public ResponseEntity<Response>  getVoteDetails(@ApiParam(name = "id", value = "Numeric login to the application", required = true) @PathVariable("id") int meetingNo  )
	{
		List<VotingBean> vlist = new ArrayList<VotingBean>();
		
		try {
			vlist =	vdao.getVotingDetails(meetingNo);
			saveMetaData(true,"Tests loaded","12345");
			saveData(null, vlist);
			saveResponse(data,metaData, null);
			return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST) ;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
errorDetails.setCode("00005");
			
			if( e instanceof IncorrectResultSizeDataAccessException  || e instanceof EmptyResultDataAccessException)
				errorDetails.setDescription("Bad Request");
			else if( e instanceof DataAccessException)
				errorDetails.setDescription("Database error");
			else
				errorDetails.setDescription(e.getMessage());;
			saveMetaData(false,"Error Occured","respId12345");
			
			saveResponse(null,metaData, errorDetails);
		}
		
				
			
		return  new ResponseEntity<Response>(response, HttpStatus.OK) ;
	}
	
	private void saveMetaData(boolean success, String description, String responseId){
		
		
		metaData.setSuccess(success);
		metaData.setDescription(description);
		metaData.setResponseId(responseId);
	}

	private void saveResponse(Data data, MetaData metaData, ErrorDetails errorDet) {
		response.setData(data);
		response.setMetaData(metaData);
		response.setError(errorDet);
	}
	private void saveData(ErrorDetails erroDet, List testObj) {
		response.setError(erroDet);
			data.setOutput(testObj);
		
	}

	@ExceptionHandler(TypeMismatchException.class)

	public @ResponseBody ResponseEntity<Object> typeMismatchExceptionHandler(TypeMismatchException exception, HttpServletRequest request) {

	    metaData.setDescription(null);

		metaData.setSuccess(false);

		response.setData(null);

	    errorDetails.setCode("400");

		errorDetails.setDescription("Type mismatch exception occured");

	    response.setError(errorDetails);

	    ResponseEntity<Object> responseEntity = new ResponseEntity<Object>(

	    		   response, HttpStatus.BAD_REQUEST);

	       return responseEntity;

	}

	@ExceptionHandler(Exception.class)

	public @ResponseBody ResponseEntity<Object> generalExceptionHandler(

	              Exception exception, HttpServletRequest request) {

	      

		errorDetails.setCode("400");

		errorDetails.setDescription("Bad Request");

	       ResponseEntity<Object> responseEntity = new ResponseEntity<Object>(

	    		   response, HttpStatus.BAD_REQUEST);

	       return responseEntity;

	}
	
}
