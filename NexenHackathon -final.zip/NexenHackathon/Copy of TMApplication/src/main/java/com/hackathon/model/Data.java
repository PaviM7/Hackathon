package com.hackathon.model;

import java.util.List;

import com.hackathon.bean.ToastMastersBean;

import io.swagger.annotations.ApiModelProperty;

public class Data {
	@ApiModelProperty(position = 1, required = true, value = "brief description of the property :output ")
	private List<ToastMastersBean> output;
	
	
	public List<ToastMastersBean>  getOutput() {
		return output;
	}
	public void setOutput(List<ToastMastersBean> outputList) {
		this.output = outputList;
	}
}
