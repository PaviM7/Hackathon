package com.hackathon.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.hackathon.bean.AnnouncementBean;

public class AnnouncementRowMapper implements RowMapper<AnnouncementBean> {

	public AnnouncementBean mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
				AnnouncementBean announcementObj = new AnnouncementBean();
				
				announcementObj.setMeetingNo(rs.getInt(1));
				announcementObj.setMeetingDate(rs.getString(2));
				//System.out.println(announcementObj.getMeetingDate());
				/*String date = announcementObj.getMeetingDate();
				try {
					Date date1=new SimpleDateFormat("yyyy-mm-dd").parse(date);
					System.out.println(date1+"     "+date1.toString());
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		*/
				//System.out.println(s);

				announcementObj.setMeetingTime(rs.getString(3));
				/*System.out.println(announcementObj.getMeetingTime());
				String s1 = announcementObj.getMeetingTime();
				System.out.println(s1);
		*/
				announcementObj.setMeetingVenue(rs.getString(4));
				return announcementObj;
			
			}
	}


